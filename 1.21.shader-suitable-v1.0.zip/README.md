# Yakamoz Shaders v1.0

> **yakamoz** (Türkçe): ay ışığının geceleri deniz yüzeyinde oluşturduğu parıltılı yol.

Minecraft Java 1.21.11 için sıfırdan yazılmış bir Iris/OptiFine shader paketi. Paketin odağında su var: dalgalanan yüzey, kırılma, derinliğe göre renk, ekran-uzayı yansımalar ve geceleri suyun üzerinde titreşen ay yolu.

![Gökyüzü ve su önizlemesi](docs/sky-water-preview.png)

*Bu görsel paketin `lib/atmosphere.glsl`, `lib/waves.glsl`, `lib/water.glsl` ve `lib/tonemap.glsl` dosyalarının GPU'da doğrudan çalıştırılmasıyla üretildi; oyun içi ekran görüntüsü değil. Soldan sağa, üstte gün doğumu, öğle göğü ve öğle saatinde su; altta gün batımı, alacakaranlık ve ay yolu (yakamoz).*

---

## Kurulum

1. Fabric Loader 0.19.5, **Iris 1.10.8** ve **Sodium 0.8.14** kurulu olmalı (Minecraft 1.21.11).
2. `Yakamoz-v1.0.zip` dosyasını **açmadan** `.minecraft/shaderpacks/` klasörüne kopyala.
3. Oyunda: *Seçenekler → Görüntü Ayarları → Shader Paketleri → Yakamoz-v1.0*.
4. Ayarlar için aynı ekranda **Shader Pack Settings**'e gir. En üstteki **Profil** düğmesiyle LOW / MEDIUM / HIGH arasında geçiş yapılır.

Zip yapısı:

```
Yakamoz-v1.0.zip
└── shaders/
    ├── shaders.properties    (menü, profiller, blend modları)
    ├── block.properties      (blok → id eşlemesi)
    ├── item.properties       (eşya → id eşlemesi, eldeki ışık)
    ├── lang/                 (en_us, tr_tr)
    ├── lib/                  (ortak GLSL kütüphaneleri)
    ├── program/              (program gövdeleri)
    ├── world0/               (Overworld: 27 program)
    ├── world-1/              (Nether: gölgesiz, sisli varyant)
    └── world1/               (End: prosedürel bulutsu gökyüzü)
```

`world0/`, `world-1/` ve `world1/` içindeki dosyalar sadece hangi boyutta olduğunu ve hangi programın derleneceğini `#define` ile seçip `program/` altındaki ortak kodu `#include` eder.

## Profiller

| Ayar | LOW | MEDIUM | HIGH |
|---|---|---|---|
| Gölge çözünürlüğü / mesafesi | 1024 / 96 | 2048 / 128 | 3072 / 160 |
| Gölge filtresi | Keskin (1 örnek) | Yumuşak (6) | Çok yumuşak (12) |
| Yansıma (SSR) | Sadece gökyüzü | Düşük (16 adım) | Orta (28 adım) |
| Dalga detayı (oktav) | 6 | 10 | 14 |
| Işık huzmeleri | Kapalı | 8 örnek | 12 örnek |
| Renkli gölge, kostik, bulut gölgesi | Kapalı | Açık | Açık |
| Parlak blok yansımaları | Kapalı | Kapalı | Açık |

Elle seçilebilen ek kademeler de var: SSR **Ultra** (48 adım), 4096 gölge haritası, 24 huzme örneği.

## Ayar menüsü

- **Su:** dalga gücü, hızı, boyutu, detayı, hareketli yüzey, kırılma ve gücü, berraklık, biyom su rengi, kostikler.
- **Yansımalar:** yansıma kalitesi, parlama gücü, parlak blok yansımaları, yağmur birikintileri.
- **Aydınlatma:** güneş, ay, ortam ışığı, en düşük ışık, meşale ışığı ve titremesi, kendinden ışıma, eldeki ışık, sallanan bitkiler, rüzgar.
- **Gölgeler:** çözünürlük, mesafe, filtre, yumuşaklık, renkli gölgeler, bulut gölgeleri, güneş yolu açısı.
- **Atmosfer:** sis yoğunluğu, sabah pusu, ışık huzmeleri (güç ve kalite), bulutlar (yoğunluk ve yükseklik), yıldızlar.
- **Son işleme:** bloom, ton eşleyici (ACES / Uchimura / Reinhard), pozlama, doygunluk, kontrast, vinyet.

Menü İngilizce ve Türkçe yerelleştirilmiştir (`lang/tr_tr.lang`).

## Hangi teknik nerede?

### Render hattı

| Aşama | Dosya | Görev |
|---|---|---|
| shadow | `program/shadow.glsl` | Bozulmuş (distorted) gölge haritası, sallanan bitkiler, su kostikleri, vitray rengi |
| gbuffers (opak) | `program/gbuffers_lit.glsl` | İleri (forward) aydınlatma: güneş/ay, gökyüzü, blok ışığı, eldeki ışık, ışıma |
| gbuffers (yarı saydam) | `program/gbuffers_translucent.glsl` | Su yüzey verisi + vitray/buz rengi ayrı tamponlara |
| deferred | `program/deferred.glsl` | Gökyüzü: atmosfer, güneş diski, yıldızlar, Samanyolu, bulutlar, vanilla ay |
| composite | `program/composite.glsl` | Su: kırılma, soğurma/saçılma, SSR, Fresnel, güneş/ay parıltısı; parlak blok yansımaları |
| composite1 | `program/composite1.glsl` | Hacimsel ışık (god rays), su altında kostikli huzmeler |
| composite2 | `program/composite2.glsl` | Yükseklik sisi, sabah pusu, su/lav altı sisi, huzme bulanıklaştırma |
| composite3-4 | `program/composite3.glsl`, `composite4.glsl` | Bloom: mipmap'ten 6 kademe, ayrık Gauss bulanıklığı |
| final | `program/final.glsl` | Bloom birleştirme, göz adaptasyonu, ton eşleme, renk ayarı |

### Efektler

- **Dalgalar** (`lib/waves.glsl`): `exp(sin(x) - 1)` profilli, dalga tepelerini sivrilten yürüyen dalgaların toplamı. Her dalga sonraki dalgaların örnek noktasını kendi yönünde "sürükler", böylece tepeler rüzgârlı sudaki gibi bir araya toplanır. Yönler altın açıyla dağıtılır, hız derin su dispersiyonunu (`hız ~ √(1/frekans)`) izler. Aynı fonksiyon üç işi birden yapar: ilk 4 oktav **vertex yer değiştirmesi** (`gbuffers_water` vsh), tüm oktavlar **piksel normali** (fsh), Laplasyeni ise gölge geçişindeki **kostikler** (dalga tepeleri ışığı mercek gibi odaklar). Nilüferler de aynı dalgayla salınır.
- **Su optiği** (`lib/water.glsl`, `composite.glsl`): su yüzeyi `colortex0`'a hiç yazmaz. Composite geçişi opak sahneyi dalga normalleriyle kaydırarak okur (kırılma, sudan dışarı taşmayı engelleyen derinlik kontrolüyle), ardından yüzeyle zemin arasındaki su kalınlığına göre Beer–Lambert soğurması ve içeri saçılma uygular. Kırmızı ilk ~2 blokta söner, mavi en uzağa gider. Biyom su rengi soğurmayı ve saçılmayı etkiler, böylece bataklık suyu yeşil, okyanus mavi görünür.
- **Yansımalar:** görüş uzayında büyüyen adımlarla ışın yürütme ve ikili arama ile inceltme. Ekran dışına çıkan veya bir şeye çarpmayan ışınlar kenarlarda yumuşakça **prosedürel gökyüzüne** (bulut ve yıldızlar dahil) geçer. Gökyüzünün görünmediği yerlerde (mağaralar) yansıma, yakındaki blok ışığının sıcak rengine düşer; bu sayede **lav ve meşale ekran dışında kalsa bile** su ve cilalı zeminlerde turuncu bir yansıma görünür. Su altından bakınca Snell penceresi ve tam iç yansıma da hesaplanır.
- **Güneş ve ay parıltısı:** dalga normalleri üzerinde GGX speküler lob. Gündüz güneş, gece ay (soğuk tonda, ay evresine göre) suyun üzerinde kırılan bir ışık yolu çizer. Paketin adı bu efektten geliyor.
- **Gökyüzü** (`lib/atmosphere.glsl`): ışın yürütme yerine hava kütlesi yaklaşımıyla analitik Rayleigh + Mie tek saçılma, ozon soğurması (alacakaranlıkta mor-mavi zenit) ve çoklu saçılma dolgusu. Ay, aynı modelin ikinci ve soğuk bir ışık kaynağı. Güneş ışığının rengi atmosfer geçirgenliğinden gelir; gün batımında doğal olarak turuncuya döner. Yıldızlar 3B hücre hash'iyle üretilir, renkleri ve parıldamaları rastgeledir, gök kutbu etrafında güneşle birlikte döner. Hafif bir Samanyolu da eklidir.
- **Bulutlar:** `CLOUD_HEIGHT` yüksekliğinde 2B prosedürel katman. Işığa doğru ikinci bir örnekle kendi gölgesini hesaplar, "powder" terimi ve ileri saçılmalı faz fonksiyonuyla gümüş kenar oluşturur. Aynı yoğunluk fonksiyonu arazinin üzerinde hareket eden **bulut gölgeleri** düşürür.
- **Gölgeler** (`lib/shadows.glsl`): oyuncu yakınına daha fazla çözünürlük veren radyal bozulma, texel boyutuna göre ölçeklenen normal-offset bias, altın açılı disk üzerinde donanım filtreli PCF (dünya uzayında sabit yarı gölge genişliği). Renkli gölgeler `shadowtex0` ile `shadowtex1` farkından bulunur: vitray camdan geçen ışık camın rengini, sudan geçen ışık kostik desenini alır.
- **Blok ışığı** (`lib/lighting.glsl`): vanilla'nın blok başına doğrusal düşüşü, sıfıra inen yumuşak bir ters-kare eğrisine dönüştürülür. Renk sıcak turuncudur (~2000 K) ve iki frekanslı gürültüyle hafifçe titrer.
- **Lav:** tam ışıma, yüzeyde yavaşça "nefes alan" bir ısı deseni, HDR değerleri sayesinde bloom. Lav yakınında blok ışığı 15'e çıktığı için gece etrafını belirgin şekilde aydınlatır.
- **Eldeki ışık:** `heldItemId`, `heldItemId2`, `heldBlockLightValue`, `heldBlockLightValue2` uniform'ları kullanılır. Işık sağ veya sol elin konumundan (`isRightHanded`) yayılır ve yerleştirilmiş ışıklarla aynı düşüş eğrisini izler. Rengi eşyaya göre değişir (meşale turuncu, ruh meşalesi camgöbeği, bakır meşale yeşil, deniz feneri soğuk beyaz). Lav kovası blok eşyası olmadığı için seviyesi shader'da 15 kabul edilir. Elde ve yerdeki ışıklı eşyaların alevi `currentRenderedItemId` ile parlar.
- **Hacimsel ışık:** gölge projeksiyonu afin olduğu için ışın doğrudan gölge klip uzayında enterpolasyonla yürütülür. Yüksekliğe bağlı yoğunluk sisi vadilerde tutar. Su altında huzmeler kostik desenini taşır ve soğurulur.
- **Sis:** görüş ışını boyunca analitik integrallenmiş üstel yükseklik sisi. Rengi aynı yöndeki gökyüzünden gelir (hava perspektifi). Gün doğumunda vadilere çöken bir sabah pusu da var.
- **Son işleme:** bloom için HDR sahnenin donanım mipmap'leri kullanılır (6 kademe, tek render hedefinde yan yana). Göz adaptasyonu `eyeBrightnessSmooth` ile çalışır: mağarada açılır, meşale yanında kısılır. Çok karanlık tonlar insan gözünün gece görüşü gibi maviye kayar. Ton eşleyici olarak ACES (Stephen Hill fit), Uchimura veya Reinhard-Jodie seçilebilir.

### G-buffer düzeni

| Tampon | Format | İçerik |
|---|---|---|
| colortex0 | RGBA16F | Aydınlatılmış HDR sahne |
| colortex1 | RGBA16 | Dünya normali (oktahedral) ve gökyüzü ışığı |
| colortex2 | RGBA8 | Materyal kodu, pürüzsüzlük/metal ve blok ışığı |
| colortex3 | RGBA16F | Yarı saydam katman, ön-çarpımlı (vitray, yağmur, parçacıklar) |
| colortex4 | RGBA16 | Yarı saydam normal ile paketlenmiş materyal ve gök ışığı |
| colortex5 | RGBA16 | Su: blok ışığı ve biyom rengi (RGB565) |
| colortex6 | RGBA16F | Hacimsel ışık |
| colortex7 | RGBA16F | Bloom kademeleri |

## Doğrulama

- Her program GLSL `#version 330 compatibility` ile yazıldı. 27 Overworld, 25 Nether ve 25 End programı, Iris'in `#include` çözümlemesi taklit edilerek bir NVIDIA OpenGL 4.6 sürücüsünde **derlenip link edildi**. Bu test LOW, MEDIUM, HIGH+Ultra ve "her şey kapalı" ayar kombinasyonlarında tekrarlandı ve hiç hata çıkmadı.
- Tüm kaynaklar Iris 1.10.8'in kendi içinde gelen **JCPP ön işlemcisi** ve **glsl-transformer** ayrıştırıcısından da geçirildi (262 kaynak, 0 hata).
- Kullanılan tüm uniform, program ve `shaders.properties` anahtarlarının isimleri Iris 1.10.8 jar'ından kontrol edildi.

## Bilinen sınırlamalar

- Su, normal mapping ve kırılmayı ekran uzayında yapar. Ekranın dışındaki nesneler SSR'da görünmez, onların yerine gökyüzü veya blok ışığı rengi gelir.
- Blok ışığı vanilla lightmap'inden gelir. Shader bir ışığın lavdan mı meşaleden mi geldiğini bilemez, bu yüzden hepsi sıcak turuncudur. Eldeki ışığın rengi ise eşyaya göre değişir.
- Vanilla bulutlar kapalıdır; onların yerini prosedürel bulut katmanı alır.
- Labpbr ve normal/specular kaynak paketleri desteklenmez; materyaller blok kimliğinden belirlenir.
