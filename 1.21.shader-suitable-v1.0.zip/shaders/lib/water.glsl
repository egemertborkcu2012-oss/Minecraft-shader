/*
    YAKAMOZ SHADERS - water.glsl
    Water optics shared by the composite passes (absorption, in-scattering,
    biome tint handling). Distances are in blocks (~metres).
*/

const vec3 WATER_ABSORB  = vec3(0.400, 0.055, 0.050);   // red dies first, blue travels furthest
const vec3 WATER_SCATTER = vec3(0.006, 0.030, 0.036);   // in-scattered (milky) colour

vec3 normalizedTint(vec3 tint) {
    return tint / max(maxOf(tint), 1e-3);
}

// Absorption coefficient, nudged by the biome water colour (swamps, warm oceans...)
vec3 waterAbsorption(vec3 tint) {
    vec3 tn = normalizedTint(tint);
    return (WATER_ABSORB + (1.0 - tn) * (0.22 * WATER_BIOME_TINT)) / WATER_CLARITY;
}

vec3 waterScatterColor(vec3 tint) {
    vec3 tn = normalizedTint(tint);
    return WATER_SCATTER * mix(vec3(1.0), tn * 1.1, WATER_BIOME_TINT * 0.6);
}

// Default ocean tint (#3F76E4) used when the surface colour is unknown
const vec3 DEFAULT_WATER_TINT = vec3(0.247, 0.463, 0.894);

// Light travelling through a slab of water: transmittance + in-scattering
vec3 waterVolume(vec3 background, float thickness, vec3 tint, vec3 lightAmount) {
    vec3 absorb = waterAbsorption(tint);
    vec3 T = exp(-absorb * thickness);
    vec3 inscatter = waterScatterColor(tint) * lightAmount * (1.0 - T) / max(absorb, vec3(0.02)) * 0.12;
    return background * T + inscatter;
}
