/*
    YAKAMOZ SHADERS - shadows.glsl
    Shadow-map distortion (shared by the shadow pass and every lookup)
    and soft, coloured shadow sampling.

    Define SHADOW_LOOKUP before including to get the sampling helpers.
    Requires uniforms.glsl, common.glsl, settings.glsl.
*/

#define SHADOW_DISTORT 0.85
#define SHADOW_DEPTH_SCALE 0.2
// shadowcolor0 is an 8-bit target: colours are stored halved so caustics can exceed 1
#define SHADOWCOLOR_SCALE 2.0

float shadowDistortFactor(vec2 clipXY) {
    return length(clipXY) * SHADOW_DISTORT + (1.0 - SHADOW_DISTORT);
}
vec3 distortShadowClip(vec3 clip) {
    return vec3(clip.xy / shadowDistortFactor(clip.xy), clip.z * SHADOW_DEPTH_SCALE);
}

#ifdef SHADOW_LOOKUP
uniform sampler2DShadow shadowtex0;
uniform sampler2DShadow shadowtex1;
uniform sampler2D shadowcolor0;

vec3 shadowClipPos(vec3 playerPos) {
    return (shadowProjection * (shadowModelView * vec4(playerPos, 1.0))).xyz;
}

// rgb = light transmitted to the surface, a = how much the shadow map can be trusted
vec4 sampleShadow(vec3 playerPos, vec3 normalW, float NdotL, float dither, float subsurface) {
    vec3 clip0 = shadowClipPos(playerPos);
    float fade = 1.0 - smoothstep(0.80, 0.97, length(clip0.xy));
    if (fade <= 0.0) return vec4(1.0, 1.0, 1.0, 0.0);

    // normal-offset bias, scaled with the local texel footprint
    float f = shadowDistortFactor(clip0.xy);
    float texelWorld = 2.0 * shadowDistance / float(shadowMapResolution) * f;
    float slope = 1.0 - sat(abs(NdotL));
    float offset = texelWorld * mix(1.3 + 2.0 * slope, 0.6, subsurface);
    vec3 clip = shadowClipPos(playerPos + normalW * offset);
    vec3 sp = distortShadowClip(clip) * 0.5 + 0.5;
    if (sp.z >= 1.0) return vec4(1.0, 1.0, 1.0, fade);
    sp.z -= 0.00002;

    // keep the penumbra width roughly constant in world space
    float radius = max(SHADOW_SOFTNESS * 0.05 / (2.0 * shadowDistance * f), 0.8 / float(shadowMapResolution));

    // soft opaque shadow: rotated golden-angle disc of hardware-filtered taps
    float vis = 0.0;
#if SHADOW_FILTER == 0
    vis = texture(shadowtex1, sp);
#else
#if SHADOW_FILTER == 1
    const int TAPS = 6;
#else
    const int TAPS = 12;
#endif
    // distant surfaces need fewer taps (their penumbra is sub-pixel anyway)
    int taps = length(playerPos) > 48.0 ? TAPS / 2 : TAPS;
    float angle = dither * TAU;
    for (int i = 0; i < taps; i++) {
        float r = sqrt((float(i) + 0.5) / float(taps));
        float theta = float(i) * 2.39996323 + angle;
        vec2 o = vec2(cos(theta), sin(theta)) * (r * radius);
        vis += texture(shadowtex1, vec3(sp.xy + o, sp.z));
    }
    vis /= float(taps);
#endif

    vec3 light = vec3(vis);
#ifdef COLORED_SHADOWS
    // something translucent (water, stained glass) between us and the light tints it
    float translucent = texture(shadowtex1, sp) - texture(shadowtex0, sp);
    if (translucent > 0.002) {
        vec3 tint = texture(shadowcolor0, sp.xy).rgb * SHADOWCOLOR_SCALE;
        light *= mix(vec3(1.0), tint, translucent);
    }
#endif
    return vec4(light, fade);
}

// Single tap visibility for ray marching (volumetric light). Returns rgb transmittance.
vec3 shadowVisibilityAt(vec3 shadowClip, bool coloured) {
    vec3 sp = distortShadowClip(shadowClip) * 0.5 + 0.5;
    if (any(lessThan(sp.xy, vec2(0.0))) || any(greaterThan(sp, vec3(1.0)))) return vec3(1.0);
    float v1 = texture(shadowtex1, sp);
    vec3 result = vec3(v1);
#ifdef COLORED_SHADOWS
    if (coloured) {
        float v0 = texture(shadowtex0, sp);
        if (v1 - v0 > 0.01) result = vec3(v0) + (v1 - v0) * texture(shadowcolor0, sp.xy).rgb * SHADOWCOLOR_SCALE;
    }
#endif
    return result;
}
#endif
