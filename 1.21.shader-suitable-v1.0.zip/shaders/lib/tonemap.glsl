/*
    YAKAMOZ SHADERS - tonemap.glsl
      0: ACES (Stephen Hill's fitted RRT + ODT)
      1: Uchimura (Gran Turismo) - long linear section, gentle shoulder
      2: Reinhard-Jodie          - soft and desaturated highlights
*/

vec3 tonemapACES(vec3 c) {
    const mat3 inputMat  = mat3(0.59719, 0.07600, 0.02840,
                                0.35458, 0.90834, 0.13383,
                                0.04823, 0.01566, 0.83777);
    const mat3 outputMat = mat3( 1.60475, -0.10208, -0.00327,
                                -0.53108,  1.10813, -0.07276,
                                -0.07367, -0.00605,  1.07602);
    c = inputMat * c;
    vec3 a = c * (c + 0.0245786) - 0.000090537;
    vec3 b = c * (0.983729 * c + 0.4329510) + 0.238081;
    return sat(outputMat * (a / b));
}

vec3 tonemapUchimura(vec3 x) {
    const float P = 1.0;    // max brightness
    const float a = 1.0;    // contrast
    const float m = 0.22;   // linear section start
    const float l = 0.4;    // linear section length
    const float c = 1.33;   // black tightness
    float l0 = ((P - m) * l) / a;
    float S0 = m + l0;
    float S1 = m + a * l0;
    float C2 = (a * P) / (P - S1);
    float CP = -C2 / P;
    vec3 w0 = 1.0 - smoothstep(vec3(0.0), vec3(m), x);
    vec3 w2 = step(vec3(m + l0), x);
    vec3 w1 = 1.0 - w0 - w2;
    vec3 T = m * pow(max(x, vec3(0.0)) / m, vec3(c));
    vec3 S = P - (P - S1) * exp(CP * (x - S0));
    vec3 L = m + a * (x - m);
    return sat(T * w0 + L * w1 + S * w2);
}

vec3 tonemapReinhardJodie(vec3 c) {
    float l = luma(c);
    vec3 tc = c / (1.0 + c);
    return sat(mix(c / (1.0 + l), tc, tc));
}

vec3 tonemap(vec3 c) {
#if TONEMAP == 0
    return tonemapACES(c);
#elif TONEMAP == 1
    return tonemapUchimura(c);
#else
    return tonemapReinhardJodie(c);
#endif
}

vec3 linearToSrgb(vec3 c) {
    c = sat(c);
    vec3 lo = c * 12.92;
    vec3 hi = 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055;
    return mix(lo, hi, step(vec3(0.0031308), c));
}
