/*
    YAKAMOZ SHADERS - lighting.glsl
    Forward lighting shared by every g-buffer program:
      sun/moon (shadow mapped, cloud shadowed), sky ambient, warm
      flickering block light, real-time held light, emission and a
      GGX specular lobe for smooth / wet surfaces.

    Requires uniforms, common, settings, materials, atmosphere and
    (overworld) shadows.glsl with SHADOW_LOOKUP.
*/

const vec3  BLOCKLIGHT_COLOR     = vec3(1.00, 0.55, 0.22);
const float BLOCKLIGHT_INTENSITY = 2.6;

// Vanilla light levels drop by one per block. Re-shape that linear ramp
// into a softer, inverse-square looking falloff that still reaches zero.
float blockLightFalloff(float lm) {
    float d = (1.0 - lm) * 15.0;
    return smoothstep(0.0, 0.2, lm) / (1.0 + d * d * 0.09);
}

float torchFlicker() {
#ifdef TORCH_FLICKER
    float t = frameTimeCounter;
    float n = valueNoise(vec2(t * 7.3, 0.5)) * 0.6 + valueNoise(vec2(t * 15.1, 3.7)) * 0.4;
    return 0.93 + 0.14 * n;
#else
    return 1.0;
#endif
}

vec3 blockLight(float lmBlock) {
    return BLOCKLIGHT_COLOR * (blockLightFalloff(lmBlock) * BLOCKLIGHT_INTENSITY * BLOCKLIGHT_BRIGHTNESS * torchFlicker());
}

// ---------------------------------------------------------------
//  Held light: heldItemId / heldItemId2 + heldBlockLightValue(2)
// ---------------------------------------------------------------
float heldLightLevel(int id, int blockLightValue) {
    float level = float(blockLightValue);
    if (id == ID_LAVA) level = max(level, 15.0);       // lava bucket is not a block item
    return level;
}

vec3 heldLightFrom(int id, float level, vec3 lightPos, vec3 playerPos, vec3 normal) {
    if (level < 0.5) return vec3(0.0);
    vec3 toLight = lightPos - playerPos;
    float dist = length(toLight);
    float lm = sat((level - dist) / 15.0);              // same curve as placed lights
    if (lm <= 0.0) return vec3(0.0);
    float lambert = sat(dot(normal, toLight / max(dist, 1e-3))) * 0.75 + 0.25;
    return lightColorForId(id) * (blockLightFalloff(lm) * lambert);
}

vec3 heldLight(vec3 playerPos, vec3 normal) {
#ifdef HANDLIGHT
    float l1 = heldLightLevel(heldItemId, heldBlockLightValue);
    float l2 = heldLightLevel(heldItemId2, heldBlockLightValue2);
    if (l1 + l2 < 0.5) return vec3(0.0);
    vec3 right = gbufferModelViewInverse[0].xyz;
    vec3 up    = gbufferModelViewInverse[1].xyz;
    vec3 fwd   = -gbufferModelViewInverse[2].xyz;
    float side = isRightHanded ? 1.0 : -1.0;
    vec3 mainPos =  right * (0.35 * side) - up * 0.25 + fwd * 0.4;
    vec3 offPos  = -right * (0.35 * side) - up * 0.25 + fwd * 0.4;
    vec3 light = heldLightFrom(heldItemId, l1, mainPos, playerPos, normal)
               + heldLightFrom(heldItemId2, l2, offPos, playerPos, normal);
    return light * (BLOCKLIGHT_INTENSITY * HANDLIGHT_BRIGHTNESS * torchFlicker());
#else
    return vec3(0.0);
#endif
}

// ---------------------------------------------------------------
//  Specular
// ---------------------------------------------------------------
vec3 fresnelSchlick(float cosTheta, vec3 F0) {
    return F0 + (1.0 - F0) * pow(1.0 - sat(cosTheta), 5.0);
}

// GGX / Smith specular, already multiplied by N.L (light = irradiance / PI units)
vec3 specularGGX(vec3 N, vec3 V, vec3 L, float roughness, vec3 F0) {
    vec3 H = normalize(V + L);
    float NdotL = max(dot(N, L), 0.0);
    float NdotV = max(dot(N, V), 1e-3);
    float NdotH = max(dot(N, H), 0.0);
    float VdotH = max(dot(V, H), 0.0);
    float a  = roughness * roughness;
    float a2 = a * a;
    float d  = NdotH * NdotH * (a2 - 1.0) + 1.0;
    float D  = a2 / (PI * d * d);
    float k  = a * 0.5;
    float G  = (NdotL / (NdotL * (1.0 - k) + k)) * (NdotV / (NdotV * (1.0 - k) + k));
    vec3  F  = fresnelSchlick(VdotH, F0);
    return min(D * G * F * (PI / (4.0 * NdotV)), vec3(400.0));
}

// ---------------------------------------------------------------
//  Per-dimension light colours (evaluated in vertex shaders)
// ---------------------------------------------------------------
void getLightColors(out vec3 directCol, out vec3 ambientCol) {
#if defined WORLD_NETHER
    directCol  = vec3(0.0);
    ambientCol = toLinear(fogColor) * 0.55 + vec3(0.050, 0.030, 0.022);
#elif defined WORLD_END
    directCol  = vec3(0.0);
    ambientCol = vec3(0.075, 0.060, 0.110);
#else
    computeLightColors(directCol, ambientCol);
#endif
}

// ---------------------------------------------------------------
//  Emission of light-source blocks (only their bright texels glow)
// ---------------------------------------------------------------
float blockEmission(int id, vec3 srgb) {
    float m = maxOf(srgb);
    float s = 0.0;
    if (id == ID_LAVA)                   s = 5.5;
    else if (id == ID_FIRE)              s = 4.0 * smoothstep(0.25, 0.65, m);
    else if (id == ID_TORCH || id == ID_SOUL_LIGHT || id == ID_COPPER_LIGHT)
                                         s = 5.0 * smoothstep(0.62, 0.92, m);
    else if (id == ID_LIGHT_BLOCK || id == ID_COOL_LIGHT)
                                         s = 2.6 * smoothstep(0.35, 0.80, m);
    else if (id == ID_MAGMA)             s = 2.8 * smoothstep(0.45, 0.85, m) * smoothstep(0.1, 0.4, srgb.r - srgb.b);
    else if (id == ID_REDSTONE_LIGHT)    s = 3.0 * smoothstep(0.55, 0.85, srgb.r) * (1.0 - smoothstep(0.35, 0.65, srgb.g));
    else if (id == ID_SMALL_GLOW)        s = 1.3 * smoothstep(0.50, 0.85, m);
    else if (id == ID_PORTAL || id == ID_END_PORTAL) s = 2.2;
    return s * EMISSIVE_BRIGHTNESS;
}

// ---------------------------------------------------------------
//  Main surface shading
// ---------------------------------------------------------------
vec3 shadeSurface(vec3 albedo, vec3 normal, vec2 lm, vec3 playerPos, float subsurface,
                  float smoothness, float metalness, vec3 directCol, vec3 ambientCol, float dither) {
    vec3 color = vec3(0.0);
    vec3 diffuseColor = albedo * (1.0 - metalness * 0.85);

#ifdef WORLD_OVERWORLD
    vec3 L = lightDirection();
    float NdotL = dot(normal, L);
    float diffuse = max(NdotL, 0.0) + subsurface * (max(-NdotL, 0.0) * 0.55 + 0.12);

    vec3 shadow = vec3(0.0);
    if (diffuse > 1e-4 && maxOf(directCol) > 1e-5) {
        float fallback = smoothstep(0.75, 0.95, lm.y);
#if defined SHADOW_LOOKUP && !defined PROG_HAND
        vec4 sm = sampleShadow(playerPos, normal, NdotL, dither, subsurface);
        shadow = mix(vec3(fallback), sm.rgb, sm.a);
#else
        // the first-person hand sits inside the player's own shadow: use the sky light instead
        shadow = vec3(fallback);
#endif
        shadow *= cloudShadow(playerPos + cameraPosition);
        // sunlight never reaches where the sky cannot: stops leaks into caves
        shadow *= smoothstep(0.0, 0.12, lm.y);
    }
    vec3 lit = directCol * (diffuse * shadow);
    lit += ambientCol * (lm.y * lm.y) * (0.62 + 0.38 * normal.y);
#else
    vec3 lit = ambientCol * (0.75 + 0.25 * normal.y);
#endif

    lit += blockLight(lm.x);
    lit += heldLight(playerPos, normal);
    lit += vec3(0.60, 0.70, 1.00) * (0.0045 * MIN_LIGHT) + vec3(nightVision * 0.25);

    color = diffuseColor * lit;

#ifdef WORLD_OVERWORLD
    if (smoothness > 0.05) {
        vec3 V = -normalize(playerPos);
        float roughness = max(1.0 - smoothness, 0.05);
        vec3 F0 = mix(vec3(0.04), albedo, metalness);
        color += directCol * shadow * specularGGX(normal, V, L, roughness, F0) * SPECULAR_STRENGTH;
    }
#endif
    return color;
}
