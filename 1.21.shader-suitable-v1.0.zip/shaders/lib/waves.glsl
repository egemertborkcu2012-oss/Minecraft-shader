/*
    YAKAMOZ SHADERS - waves.glsl

    The water surface is a sum of sharp-crested travelling waves using an
    exp(sin(x) - 1) profile. Each wave "drags" the sample point of the
    following ones along its own direction, which bunches crests together
    the way wind-driven water does. Wave directions follow the golden
    angle so no two octaves line up; speed follows deep-water dispersion
    (phase speed ~ sqrt(1 / frequency)).

    The same function drives vertex displacement (first few octaves),
    per-pixel normals (all octaves) and the caustics in the shadow pass,
    so geometry, shading and light patterns always agree.
*/

float waterHeight(vec2 worldXZ, int octaves) {
    vec2 p = worldXZ / WAVE_SCALE;
    float t = frameTimeCounter * WAVE_SPEED;
    float freq  = 0.21;
    float amp   = 1.0;
    float ang   = 0.73;
    float h     = 0.0;
    float total = 0.0;
    for (int i = 0; i < octaves; i++) {
        vec2 d = vec2(cos(ang), sin(ang));
        float x  = dot(d, p) * freq + t * sqrt(freq) * 1.35;
        float w  = exp(sin(x) - 1.0);
        float dw = w * cos(x);
        h     += w * amp;
        total += amp;
        p     -= d * (dw * amp * 0.28 / freq);
        freq  *= 1.28;
        amp   *= 0.76;
        ang   += 2.39996323;
    }
    return h / total;
}

// Vertical displacement in blocks used by gbuffers_water.vsh
float waterDisplacement(vec2 worldXZ) {
    return (waterHeight(worldXZ, 4) - 0.45) * 0.14 * WAVE_STRENGTH;
}

// World-space normal of the animated surface.
// detail fades the small octaves out (used for distant water).
vec3 waterNormal(vec2 worldXZ, int octaves, float strength) {
    const float e = 0.035;
    float h0 = waterHeight(worldXZ, octaves);
    float hx = waterHeight(worldXZ + vec2(e, 0.0), octaves);
    float hz = waterHeight(worldXZ + vec2(0.0, e), octaves);
    vec2 grad = vec2(hx - h0, hz - h0) / e * strength;
    return normalize(vec3(-grad.x, 1.0, -grad.y));
}

// Caustic brightness under the surface: crests act like converging lenses.
float waterCaustics(vec2 worldXZ) {
    const float e = 0.15;
    const int oct = 7;
    float h   = waterHeight(worldXZ, oct);
    float hx1 = waterHeight(worldXZ + vec2(e, 0.0), oct);
    float hx2 = waterHeight(worldXZ - vec2(e, 0.0), oct);
    float hz1 = waterHeight(worldXZ + vec2(0.0, e), oct);
    float hz2 = waterHeight(worldXZ - vec2(0.0, e), oct);
    float laplacian = (hx1 + hx2 + hz1 + hz2 - 4.0 * h) / (e * e);
    float c = exp(-laplacian * 0.9 * WAVE_STRENGTH);
    return mix(1.0, c * 0.85, CAUSTICS_STRENGTH * 0.85);
}
