/*
    ============================================================
     YAKAMOZ SHADERS - settings.glsl
     Every option that appears in the in-game shader menu lives
     in this single file. Iris rewrites these lines when the user
     changes a setting, so keep one option per line.
    ============================================================
*/

// ------------------------------------------------------------
//  Water
// ------------------------------------------------------------
#define WAVE_STRENGTH 1.0           // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 1.75 2.0 2.5 3.0]
#define WAVE_SPEED 1.0              // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 2.5 3.0]
#define WAVE_SCALE 1.0              // [0.5 0.75 1.0 1.25 1.5 2.0]
#define WAVE_OCTAVES 14             // [4 6 8 10 12 14 16 20]
#define WATER_VERTEX_WAVES
#define WATER_REFRACTION
#define REFRACTION_STRENGTH 1.0     // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define WATER_CLARITY 1.0           // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define WATER_BIOME_TINT 0.5        // [0.0 0.25 0.5 0.75 1.0]
#define WATER_CAUSTICS
#define CAUSTICS_STRENGTH 1.0       // [0.25 0.5 0.75 1.0 1.5 2.0]

// ------------------------------------------------------------
//  Reflections
// ------------------------------------------------------------
#define SSR_QUALITY 2               // [0 1 2 3]
#define SSR_SHINY_BLOCKS
#define RAIN_PUDDLES
#define SPECULAR_STRENGTH 1.0       // [0.0 0.25 0.5 0.75 1.0 1.5 2.0]

// ------------------------------------------------------------
//  Lighting
// ------------------------------------------------------------
#define SUN_BRIGHTNESS 1.0          // [0.5 0.75 1.0 1.25 1.5 2.0]
#define MOON_BRIGHTNESS 1.0         // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define AMBIENT_BRIGHTNESS 1.0      // [0.5 0.75 1.0 1.25 1.5 2.0]
#define BLOCKLIGHT_BRIGHTNESS 1.0   // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define TORCH_FLICKER
#define HANDLIGHT
#define HANDLIGHT_BRIGHTNESS 1.0    // [0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define EMISSIVE_BRIGHTNESS 1.0     // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define MIN_LIGHT 1.0               // [0.0 0.5 1.0 2.0 4.0]
#define WAVING_PLANTS
#define WIND_STRENGTH 1.0           // [0.25 0.5 0.75 1.0 1.5 2.0]

// ------------------------------------------------------------
//  Shadows
// ------------------------------------------------------------
const int shadowMapResolution = 3072;   // [1024 1536 2048 3072 4096]
const float shadowDistance = 160.0;     // [64.0 96.0 128.0 160.0 192.0 256.0]
const float sunPathRotation = -25.0;    // [-45.0 -35.0 -25.0 -15.0 0.0 15.0 25.0 35.0 45.0]
const float shadowDistanceRenderMul = 1.0;
const bool shadowHardwareFiltering = true;
const float ambientOcclusionLevel = 1.0;
const float eyeBrightnessHalflife = 4.0;
const float wetnessHalflife = 300.0;
const float drynessHalflife = 70.0;
#define SHADOW_FILTER 2             // [0 1 2]
#define SHADOW_SOFTNESS 1.0         // [0.5 0.75 1.0 1.5 2.0 3.0]
#define COLORED_SHADOWS
#define CLOUD_SHADOWS

// ------------------------------------------------------------
//  Atmosphere
// ------------------------------------------------------------
#define FOG_DENSITY 1.0             // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define MORNING_MIST
#define VOLUMETRIC_LIGHT
#define VL_STRENGTH 1.0             // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define VL_SAMPLES 12               // [6 8 12 16 24]
#define CLOUDS
#define CLOUD_COVERAGE 0.5          // [0.2 0.3 0.4 0.5 0.6 0.7 0.8]
#define CLOUD_HEIGHT 260.0          // [192.0 224.0 260.0 320.0 400.0]
#define STARS
#define STAR_BRIGHTNESS 1.0         // [0.25 0.5 0.75 1.0 1.5 2.0 3.0]

// ------------------------------------------------------------
//  Post processing
// ------------------------------------------------------------
#define BLOOM
#define BLOOM_STRENGTH 1.0          // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define TONEMAP 0                   // [0 1 2]
#define EXPOSURE 1.0                // [0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.25 1.5 1.75 2.0]
#define SATURATION 1.0              // [0.6 0.8 0.9 1.0 1.1 1.2 1.3 1.5]
#define CONTRAST 1.0                // [0.8 0.9 1.0 1.1 1.2]
#define VIGNETTE 0.25               // [0.0 0.1 0.25 0.4 0.6]
