/*
    YAKAMOZ SHADERS - atmosphere.glsl

    A compact analytic atmosphere:
      * single scattering with constant-density Rayleigh + Mie layers,
        evaluated with an airmass approximation instead of ray marching
      * ozone absorption so twilight skies keep their blue/violet zenith
      * cheap multiple-scattering fill term
      * the moon is a second (cold, dim) light source of the same model
      * procedural stars + milky way, rotating with the celestial pole
      * a 2D procedural cloud layer with self shadowing and silver lining

    Everything works in world-space directions (y = up).
    Requires uniforms.glsl, common.glsl, settings.glsl.
*/

const vec3  ATM_RAYLEIGH = vec3(0.0465, 0.1080, 0.2650);   // zenith optical depth
const float ATM_MIE      = 0.0170;
const vec3  ATM_OZONE    = vec3(0.0130, 0.0360, 0.0018);
const vec3  ATM_EXTINCT  = ATM_RAYLEIGH + vec3(ATM_MIE * 1.11) + ATM_OZONE;
const vec3  ATM_SCATTER_EXT = ATM_RAYLEIGH + vec3(ATM_MIE * 1.11);

const float SUN_ILLUMINANCE  = 3.4;     // direct sun at noon (linear HDR units)
const float SKY_RADIANCE     = 5.5;     // sky brightness scale
const float MOON_ILLUMINANCE = 0.20;    // direct moonlight at full moon
const vec3  MOON_TINT        = vec3(0.55, 0.70, 1.00);
const float MOON_SKY_RATIO   = 0.012;   // moon-lit sky vs sun-lit sky
const vec3  NIGHT_AIRGLOW    = vec3(0.0035, 0.0050, 0.0095);

vec3 sunDirection()   { return normalize(mat3(gbufferModelViewInverse) * sunPosition); }
vec3 moonDirection()  { return normalize(mat3(gbufferModelViewInverse) * moonPosition); }
vec3 lightDirection() { return normalize(mat3(gbufferModelViewInverse) * shadowLightPosition); }

// Relative optical air mass, finite (~40) at the horizon
float airmass(float cosZenith) {
    float c = max(cosZenith, 0.0);
    return 1.0 / (c + 0.025 * exp(-11.0 * c));
}
vec3 atmTransmittance(float cosZenith) {
    return exp(-ATM_EXTINCT * airmass(cosZenith));
}

// Phase functions normalised to an average of 1 over the sphere
float phaseRayleigh(float mu) { return 0.75 * (1.0 + mu * mu); }
float phaseHG(float mu, float g) {
    float g2 = g * g;
    return (1.0 - g2) / pow(max(1.0 + g2 - 2.0 * g * mu, 1e-4), 1.5);
}

float moonPhaseBrightness() {
    // moonPhase 0 = full moon, 4 = new moon
    return mix(1.0, 0.12, 1.0 - abs(float(moonPhase) - 4.0) * 0.25);
}

// Sky radiance in direction dir lit by one light source L
vec3 scatterLight(vec3 dir, vec3 L, float g) {
    float viewY = max(dir.y, 0.0);
    float mu = dot(dir, L);

    // Rayleigh (8 km scale height) and Mie (1.2 km) see different path
    // lengths towards the horizon; capping them keeps the horizon from
    // turning into a white wall.
    float mR = min(airmass(viewY + 0.02), 14.0);
    float mM = min(mR, 5.0);
    // light reaching high-altitude scatterers travels through less air
    float mLight = airmass(L.y) * mix(1.0, 0.42, sqrt(viewY));
    vec3  lightT = exp(-ATM_EXTINCT * mLight);
    vec3  lightTSoft = exp(-ATM_EXTINCT * min(mLight, 2.5));

    vec3 tauR = ATM_RAYLEIGH * mR;
    float tauM = ATM_MIE * mM;
    vec3 tauExt = tauR + vec3(tauM * 1.11);
    vec3 opacity = 1.0 - exp(-tauExt);
    vec3 single  = (tauR * phaseRayleigh(mu) + tauM * phaseHG(mu, g)) / tauExt;
    vec3 multi   = tauR / tauExt * 0.14;

    return opacity * (single * lightT + multi * lightTSoft);
}

// Atmosphere only (no sun disc, stars or clouds). Also used for fog,
// ambient light and reflections.
vec3 skyAtmosphere(vec3 dir) {
    vec3 sunDir  = sunDirection();
    vec3 moonDir = -sunDir;

    vec3 d = dir;
    d.y = max(d.y, 0.0);
    d = normalize(d + vec3(0.0, 1e-4, 0.0));

    float sunVis  = smoothstep(-0.24, 0.02, sunDir.y);
    float moonVis = smoothstep(-0.24, 0.02, moonDir.y);

    vec3 col = scatterLight(d, sunDir, 0.76) * (SKY_RADIANCE * sunVis);
    col += scatterLight(d, moonDir, 0.80) * MOON_TINT * (SKY_RADIANCE * MOON_SKY_RATIO * moonPhaseBrightness() * moonVis * MOON_BRIGHTNESS);

    // faint airglow so the night sky is never pitch black
    float horizon = exp(-max(dir.y, 0.0) * 6.0);
    col += NIGHT_AIRGLOW * (0.6 + 0.8 * horizon) * (1.0 - sunVis * 0.9);

    // below the horizon: darker, bluish "ground haze"
    float below = sat(-dir.y * 4.0);
    col *= mix(1.0, 0.35, below);

    // overcast weather: flat, compressed grey
    float grey = luma(col);
    grey = grey / (1.0 + grey * 0.8);
    col = mix(col, vec3(grey) * vec3(0.92, 0.96, 1.0) * 0.55, rainStrength * 0.85);
    return col;
}

// Direct light (sun or moon) and ambient sky light reaching the ground.
void computeLightColors(out vec3 directCol, out vec3 ambientCol) {
    vec3 sunDir = sunDirection();
    float sunY = sunDir.y;

    float sunFade  = smoothstep(0.0, 0.09, sunY);
    float moonFade = smoothstep(0.0, 0.09, -sunY);

    vec3 sunLight  = atmTransmittance(sunY) * (SUN_ILLUMINANCE * SUN_BRIGHTNESS * sunFade);
    vec3 moonLight = MOON_TINT * (MOON_ILLUMINANCE * MOON_BRIGHTNESS * moonPhaseBrightness() * moonFade);
    directCol = (sunLight + moonLight) * (1.0 - rainStrength * 0.85);

    vec3 horizonDir = normalize(vec3(sunDir.x, 0.0, sunDir.z) + vec3(1e-4, 0.0, 0.0));
    vec3 up    = skyAtmosphere(vec3(0.0, 1.0, 0.0));
    vec3 side1 = skyAtmosphere(normalize(horizonDir + vec3(0.0, 0.35, 0.0)));
    vec3 side2 = skyAtmosphere(normalize(-horizonDir + vec3(0.0, 0.35, 0.0)));
    ambientCol = (up * 0.5 + (side1 + side2) * 0.25) * (0.85 * AMBIENT_BRIGHTNESS);
    ambientCol += vec3(0.018, 0.024, 0.042) * MOON_BRIGHTNESS * moonPhaseBrightness() * moonFade;
}

// ---------------------------------------------------------------
//  Sun disc
// ---------------------------------------------------------------
vec3 sunDisc(vec3 dir, vec3 sunDir) {
    float mu = dot(dir, sunDir);
    float a2 = 2.0 * (1.0 - mu);                 // ~ angle^2
    const float R = 0.0175;                      // angular radius (radians)
    float disc = smoothstep(R * R * 1.15, R * R * 0.85, a2);
    float limb = sqrt(sat(1.0 - a2 / (R * R)));
    vec3 radiance = atmTransmittance(sunDir.y) * 260.0 * SUN_BRIGHTNESS;
    float horizonMask = smoothstep(-0.01, 0.01, dir.y);
    return radiance * disc * (0.45 + 0.55 * limb) * horizonMask * (1.0 - rainStrength);
}

// ---------------------------------------------------------------
//  Stars & milky way
// ---------------------------------------------------------------
// Celestial frame: the sky rotates around a pole perpendicular to the sun path.
vec3 toCelestial(vec3 dir) {
    float rot = radians(sunPathRotation);
    vec3 pole = normalize(vec3(0.0, sin(rot), cos(rot)));
    vec3 s = sunDirection();
    vec3 e1 = normalize(s - pole * dot(s, pole) + vec3(1e-5, 0.0, 0.0));
    vec3 e2 = cross(pole, e1);
    return vec3(dot(dir, e1), dot(dir, e2), dot(dir, pole));
}

vec3 starField(vec3 dir) {
#ifdef STARS
    float night = smoothstep(0.05, -0.18, sunDirection().y);
    if (night <= 0.0 || dir.y <= -0.02) return vec3(0.0);

    vec3 p = toCelestial(dir);

    // milky way: a soft band of light along a tilted great circle
    vec3 bandN = normalize(vec3(0.35, 0.82, 0.45));
    float bandDist = dot(p, bandN);
    float band = exp(-bandDist * bandDist * 40.0);
    float dust = valueNoise3(p * 4.0) * 0.55 + valueNoise3(p * 9.0) * 0.3 + valueNoise3(p * 21.0) * 0.15;
    float lanes = smoothstep(0.4, 0.75, valueNoise3(p * 7.0 + 13.0)) * exp(-bandDist * bandDist * 400.0);
    vec3 milky = vec3(0.55, 0.62, 0.85) * band * dust * (1.0 - 0.7 * lanes) * 0.014;

    // stars: one candidate per 3D cell, jittered, random colour and twinkle
    vec3 q = p * 230.0;
    vec3 cell = floor(q);
    vec3 f = fract(q) - 0.5;
    vec3 h = hash33(cell);
    float density = mix(0.035, 0.09, band);
    vec3 stars = vec3(0.0);
    if (h.x < density) {
        vec3 jitter = (hash33(cell + 17.0) - 0.5) * 0.5;
        float d = length(f - jitter);
        float bright = pow(h.y, 6.0) * 4.0 + 0.15;
        float twinkle = 0.75 + 0.25 * sin(frameTimeCounter * (1.5 + 3.0 * h.z) + h.y * TAU);
        vec3 tint = mix(vec3(1.0, 0.72, 0.50), vec3(0.62, 0.78, 1.0), h.z);
        stars = tint * bright * twinkle * smoothstep(0.36, 0.0, d) * 0.12;
    }

    float horizonFade = smoothstep(-0.02, 0.25, dir.y);
    return (stars + milky) * night * horizonFade * (1.0 - rainStrength) * STAR_BRIGHTNESS;
#else
    return vec3(0.0);
#endif
}

// ---------------------------------------------------------------
//  Clouds (2D layer at CLOUD_HEIGHT)
// ---------------------------------------------------------------
float cloudCoverage() {
    return sat(CLOUD_COVERAGE + rainStrength * 0.35 + thunderStrength * 0.1);
}

float cloudDensity(vec2 worldXZ, int octaves) {
    float t = frameTimeCounter;
    vec2 p = worldXZ * 0.0016 + vec2(t * 0.0045, t * 0.0012);
    float n = 0.0;
    float amp = 0.55;
    float total = 0.0;
    mat2 rot = mat2(0.80, 0.60, -0.60, 0.80);
    for (int i = 0; i < octaves; i++) {
        n += valueNoise(p) * amp;
        total += amp;
        p = rot * p * 2.07 + vec2(t * 0.002 * float(i + 1), 0.0);
        amp *= 0.5;
    }
    n /= total;
    float cov = cloudCoverage();
    return sat((n - (1.0 - cov) * 1.02) * 4.0);
}

// Returns colour (rgb) and opacity (a) of the cloud layer along dir.
vec4 renderClouds(vec3 dir, vec3 cloudLight, vec3 cloudAmbient, int octaves) {
#ifdef CLOUDS
    float camY = cameraPosition.y;
    if (abs(dir.y) < 0.002) return vec4(0.0);
    float t = (CLOUD_HEIGHT - camY) / dir.y;
    if (t <= 0.0) return vec4(0.0);

    vec2 hit = cameraPosition.xz + dir.xz * t;
    float density = cloudDensity(hit, octaves);
    if (density <= 0.001) return vec4(0.0);

    vec3 L = lightDirection();
    // self shadowing: sample the layer again towards the light
    vec2 toLight = L.xz / max(abs(L.y), 0.15) * 45.0;
    float densL = cloudDensity(hit + toLight, max(octaves - 2, 2));
    float lightT = exp(-densL * 2.6);
    float powder = 1.0 - exp(-density * 4.0);

    float mu = dot(dir, L);
    float phase = mix(phaseHG(mu, 0.6), phaseHG(mu, -0.2), 0.4) + 0.35;
    vec3 col = cloudLight * lightT * powder * phase * 0.75;
    col += cloudAmbient * (0.5 + 0.5 * (1.0 - density));

    float alpha = sat(density * 2.0);
    // fade with distance and near the horizon
    float fade = exp(-t * 0.00022) * smoothstep(0.0, 0.08, abs(dir.y));
    return vec4(col, alpha * fade);
#else
    return vec4(0.0);
#endif
}

// Light used to shade clouds (sun / moon above the haze layer)
void computeCloudLight(out vec3 cloudLight, out vec3 cloudAmbient) {
    vec3 sunDir = sunDirection();
    float sunVis  = smoothstep(-0.06, 0.04, sunDir.y);
    float moonVis = smoothstep(-0.06, 0.04, -sunDir.y);
    vec3 sunT = exp(-ATM_EXTINCT * airmass(sunDir.y) * 0.65);
    cloudLight = sunT * SUN_ILLUMINANCE * SUN_BRIGHTNESS * sunVis
               + MOON_TINT * MOON_ILLUMINANCE * MOON_BRIGHTNESS * moonPhaseBrightness() * moonVis;
    cloudAmbient = skyAtmosphere(vec3(0.0, 1.0, 0.0)) * 0.75 + skyAtmosphere(normalize(vec3(sunDir.x, 0.1, sunDir.z) + vec3(1e-4, 0.0, 0.0))) * 0.25;
    cloudLight *= 1.0 - rainStrength * 0.8;
}

// Cloud shadow factor for a world-space position (1 = unshadowed)
float cloudShadow(vec3 worldPos) {
    float shadow = 1.0;
#ifdef CLOUDS
#ifdef CLOUD_SHADOWS
    vec3 L = lightDirection();
    if (L.y > 0.05) {
        vec2 p = worldPos.xz + L.xz * ((CLOUD_HEIGHT - worldPos.y) / L.y);
        float d = cloudDensity(p, 3);
        shadow = 1.0 - sat(d * 1.4) * 0.72;
    }
#endif
#endif
    return shadow;
}

// Full sky: atmosphere + sun disc + stars + clouds
vec3 renderSky(vec3 dir, vec3 cloudLight, vec3 cloudAmbient, bool withSun, int cloudOctaves, out float cloudAlpha) {
    vec3 sky = skyAtmosphere(dir);
    vec3 sunDir = sunDirection();
    if (withSun) sky += sunDisc(dir, sunDir);
    vec3 stars = starField(dir);
    // keep stars from shining through the moon disc
    stars *= smoothstep(0.9990, 0.9975, dot(dir, -sunDir));
    sky += stars;

    vec4 clouds = renderClouds(dir, cloudLight, cloudAmbient, cloudOctaves);
    sky = mix(sky, clouds.rgb, clouds.a);
    cloudAlpha = clouds.a;
    return sky;
}
