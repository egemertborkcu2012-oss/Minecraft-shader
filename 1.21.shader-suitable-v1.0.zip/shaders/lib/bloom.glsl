/*
    YAKAMOZ SHADERS - bloom.glsl
    Six bloom levels (1/4 ... 1/128 resolution) packed side by side into
    one render target (colortex7). Tile i holds mip level i + 2.
*/

const int BLOOM_TILES = 6;
const float BLOOM_PAD = 0.012;

float bloomTileScale(int i) {
    return exp2(-float(i + 2));
}
// x offset = sum of all previous tile widths + padding
vec2 bloomTileOffset(int i) {
    return vec2(0.5 - exp2(-float(i + 1)) + BLOOM_PAD * float(i), BLOOM_PAD);
}

// Gaussian weights for a 9 tap kernel (sigma ~ 2 texels)
float bloomWeight(int k) {
    float x = float(k);
    return exp(-x * x / 8.0);
}
