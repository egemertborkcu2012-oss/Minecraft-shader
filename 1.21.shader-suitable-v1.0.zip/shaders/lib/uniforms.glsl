/*
    YAKAMOZ SHADERS - uniforms.glsl
    Shared (non-sampler) uniforms. Every name here is provided by Iris.
    Samplers are declared by each program so no stage binds a buffer it
    does not need.
*/

uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjection;
uniform mat4 gbufferProjectionInverse;
uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;
uniform mat4 shadowProjection;

uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 shadowLightPosition;
uniform vec3 fogColor;

uniform float sunAngle;
uniform float frameTimeCounter;
uniform int   frameCounter;
uniform int   worldTime;
uniform int   moonPhase;

uniform float rainStrength;
uniform float wetness;
uniform float thunderStrength;

uniform float viewWidth;
uniform float viewHeight;
uniform float aspectRatio;
uniform float near;
uniform float far;

uniform ivec2 eyeBrightnessSmooth;
uniform int   isEyeInWater;
uniform float nightVision;
uniform float blindness;
uniform float darknessFactor;

uniform int   heldItemId;
uniform int   heldItemId2;
uniform int   heldBlockLightValue;
uniform int   heldBlockLightValue2;
uniform bool  isRightHanded;
