/*
    YAKAMOZ SHADERS - materials.glsl
    Block / item ids (must match block.properties and item.properties)
    and the material codes written into the g-buffers.
*/

// ---- block.properties / item.properties ids ----
#define ID_WATER          10001
#define ID_LAVA           10002
#define ID_FIRE           10003
#define ID_TORCH          10004
#define ID_SOUL_LIGHT     10005
#define ID_LIGHT_BLOCK    10006
#define ID_COOL_LIGHT     10007
#define ID_MAGMA          10008
#define ID_REDSTONE_LIGHT 10009
#define ID_COPPER_LIGHT   10010
#define ID_SMALL_GLOW     10011
#define ID_GLASS          10020
#define ID_ICE            10021
#define ID_SLIME_HONEY    10022
#define ID_PORTAL         10023
#define ID_END_PORTAL     10024
#define ID_POLISHED       10030
#define ID_METAL          10031
#define ID_GEM            10032
#define ID_PLANT          10040
#define ID_TALL_LOWER     10041
#define ID_TALL_UPPER     10042
#define ID_LEAVES         10043
#define ID_VINE           10044
#define ID_LILY_PAD       10045

// ---- material codes stored in colortex2.r (x / 255) ----
#define MAT_DEFAULT   0.0
#define MAT_HAND      1.0
#define MAT_EMISSIVE  2.0
#define MAT_FOLIAGE   3.0
#define MAT_ENTITY    4.0
#define MAT_PARTICLE  5.0
#define MAT_LAVA      6.0

// ---- translucent material codes stored in colortex4.b ----
#define TMAT_NONE   0.0
#define TMAT_WATER  1.0
#define TMAT_GLASS  2.0
#define TMAT_OTHER  3.0

// Colour of light emitted by a light-source id (used by the held-light system)
vec3 lightColorForId(int id) {
    if (id == ID_LAVA)           return vec3(1.00, 0.40, 0.09);
    if (id == ID_FIRE)           return vec3(1.00, 0.50, 0.16);
    if (id == ID_SOUL_LIGHT)     return vec3(0.28, 0.80, 1.00);
    if (id == ID_COOL_LIGHT)     return vec3(0.72, 0.88, 1.00);
    if (id == ID_REDSTONE_LIGHT) return vec3(1.00, 0.16, 0.06);
    if (id == ID_COPPER_LIGHT)   return vec3(0.55, 1.00, 0.62);
    if (id == ID_LIGHT_BLOCK)    return vec3(1.00, 0.76, 0.46);
    if (id == ID_MAGMA)          return vec3(1.00, 0.35, 0.08);
    if (id == ID_SMALL_GLOW)     return vec3(0.75, 0.95, 0.85);
    return vec3(1.00, 0.55, 0.22);
}
