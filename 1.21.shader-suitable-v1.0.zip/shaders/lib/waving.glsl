/*
    YAKAMOZ SHADERS - waving.glsl
    Wind animation for plants, leaves, vines and lily pads. Used by both
    gbuffers_terrain and the shadow pass so shadows sway with the plants.
    Requires uniforms, common, settings, materials, waves.
*/

vec3 windSway(vec3 worldPos, float amplitude) {
    float t = frameTimeCounter * (1.0 + rainStrength * 0.6);
    vec2 windDir = vec2(0.94, 0.34);
    float gust = 0.55 + 0.45 * sin(t * 0.43 + dot(worldPos.xz, vec2(0.031, 0.017)));
    float phase = dot(worldPos.xz, windDir) * 0.42 + t * 1.7;
    float sway = sin(phase) * 0.65 + sin(phase * 2.17 + worldPos.y * 0.7) * 0.35;
    float flutter = sin(t * 5.3 + worldPos.x * 2.3 + worldPos.z * 1.9) * 0.18;
    vec3 offset = vec3(windDir.x, 0.0, windDir.y) * (sway * gust + flutter);
    offset.y = -abs(sway) * 0.12;
    return offset * amplitude * WIND_STRENGTH * (1.0 + rainStrength * 0.8);
}

// worldPos: world position of the vertex, isTopVertex: uv above mid point
vec3 waveVertex(vec3 worldPos, int id, bool isTopVertex, float skyLight) {
    vec3 offset = vec3(0.0);
#ifdef WAVING_PLANTS
    float exposure = smoothstep(0.2, 0.7, skyLight);       // sheltered plants stay still
    if (id == ID_PLANT || id == ID_TALL_LOWER) {
        if (isTopVertex) offset = windSway(worldPos, 0.13 * exposure);
    } else if (id == ID_TALL_UPPER) {
        offset = windSway(worldPos, (isTopVertex ? 0.26 : 0.13) * exposure);
    } else if (id == ID_LEAVES) {
        offset = windSway(worldPos * 1.3, 0.045 * exposure);
    } else if (id == ID_VINE) {
        offset = windSway(worldPos, 0.06 * exposure) * vec3(1.0, 0.3, 1.0);
    }
#endif
#ifdef WATER_VERTEX_WAVES
    if (id == ID_LILY_PAD) offset.y = waterDisplacement(worldPos.xz);
#endif
    return offset;
}
