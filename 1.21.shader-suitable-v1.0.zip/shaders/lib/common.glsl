/*
    YAKAMOZ SHADERS - common.glsl
    Small math helpers, hashing, encoding and space conversions.
    Requires uniforms.glsl.
*/

#define PI  3.14159265
#define TAU 6.28318531

float sat(float x) { return clamp(x, 0.0, 1.0); }
vec2  sat(vec2 x)  { return clamp(x, 0.0, 1.0); }
vec3  sat(vec3 x)  { return clamp(x, 0.0, 1.0); }
float sq(float x)  { return x * x; }
float maxOf(vec3 v) { return max(v.x, max(v.y, v.z)); }
float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3  toLinear(vec3 c) { return pow(max(c, vec3(0.0)), vec3(2.2)); }

// ---------------------------------------------------------------
//  Hashing (integer PCG, stable on every GPU vendor)
// ---------------------------------------------------------------
uint pcgHash(uint v) {
    uint state = v * 747796405u + 2891336453u;
    uint word = ((state >> ((state >> 28u) + 4u)) ^ state) * 277803737u;
    return (word >> 22u) ^ word;
}
float hash12(vec2 p) {
    uvec2 q = uvec2(ivec2(floor(p)));
    return float(pcgHash(q.x + pcgHash(q.y))) * (1.0 / 4294967295.0);
}
float hash13(vec3 p) {
    uvec3 q = uvec3(ivec3(floor(p)));
    return float(pcgHash(q.x + pcgHash(q.y + pcgHash(q.z)))) * (1.0 / 4294967295.0);
}
vec3 hash33(vec3 p) {
    uvec3 q = uvec3(ivec3(floor(p)));
    uint h = pcgHash(q.x + pcgHash(q.y + pcgHash(q.z)));
    uint h2 = pcgHash(h);
    uint h3 = pcgHash(h2);
    return vec3(float(h), float(h2), float(h3)) * (1.0 / 4294967295.0);
}

// Smooth 2D value noise in [0,1]
float valueNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = hash12(i);
    float b = hash12(i + vec2(1.0, 0.0));
    float c = hash12(i + vec2(0.0, 1.0));
    float d = hash12(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// Smooth 3D value noise in [0,1] (used where 2D projections would streak)
float valueNoise3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);
    float a = mix(hash13(i),                    hash13(i + vec3(1.0, 0.0, 0.0)), u.x);
    float b = mix(hash13(i + vec3(0.0, 1.0, 0.0)), hash13(i + vec3(1.0, 1.0, 0.0)), u.x);
    float c = mix(hash13(i + vec3(0.0, 0.0, 1.0)), hash13(i + vec3(1.0, 0.0, 1.0)), u.x);
    float d = mix(hash13(i + vec3(0.0, 1.0, 1.0)), hash13(i + vec3(1.0, 1.0, 1.0)), u.x);
    return mix(mix(a, b, u.y), mix(c, d, u.y), u.z);
}

// Interleaved gradient noise - cheap per-pixel dither
float gradientNoise(vec2 fragCoord) {
    return fract(52.9829189 * fract(dot(fragCoord, vec2(0.06711056, 0.00583715))));
}

// ---------------------------------------------------------------
//  Octahedral normal encoding (unit vector -> [0,1]^2)
// ---------------------------------------------------------------
vec2 encodeNormal(vec3 n) {
    n /= (abs(n.x) + abs(n.y) + abs(n.z));
    vec2 e = n.xy;
    if (n.z < 0.0) {
        e = (1.0 - abs(n.yx)) * vec2(n.x >= 0.0 ? 1.0 : -1.0, n.y >= 0.0 ? 1.0 : -1.0);
    }
    return e * 0.5 + 0.5;
}
vec3 decodeNormal(vec2 e) {
    e = e * 2.0 - 1.0;
    vec3 n = vec3(e, 1.0 - abs(e.x) - abs(e.y));
    float t = max(-n.z, 0.0);
    n.x += n.x >= 0.0 ? -t : t;
    n.y += n.y >= 0.0 ? -t : t;
    return normalize(n);
}

// Material id (0..255) + 8-bit sky light packed into one 16-bit channel
float packMatSky(float mat, float sky) {
    return (mat * 256.0 + floor(sat(sky) * 255.0 + 0.5)) / 65535.0;
}
void unpackMatSky(float v, out float mat, out float sky) {
    float x = floor(v * 65535.0 + 0.5);
    mat = floor(x / 256.0);
    sky = (x - mat * 256.0) / 255.0;
}
// RGB565 colour packed into one 16-bit channel
float packColor565(vec3 c) {
    c = floor(sat(c) * vec3(31.0, 63.0, 31.0) + 0.5);
    return (c.r * 2048.0 + c.g * 32.0 + c.b) / 65535.0;
}
vec3 unpackColor565(float v) {
    float x = floor(v * 65535.0 + 0.5);
    float r = floor(x / 2048.0);
    x -= r * 2048.0;
    float g = floor(x / 32.0);
    float b = x - g * 32.0;
    return vec3(r / 31.0, g / 63.0, b / 31.0);
}

// ---------------------------------------------------------------
//  Space conversions
// ---------------------------------------------------------------
vec3 screenToView(vec2 uv, float depth) {
    vec4 p = gbufferProjectionInverse * vec4(vec3(uv, depth) * 2.0 - 1.0, 1.0);
    return p.xyz / p.w;
}
vec3 viewToScreen(vec3 viewPos) {
    vec4 p = gbufferProjection * vec4(viewPos, 1.0);
    return (p.xyz / p.w) * 0.5 + 0.5;
}
vec3 viewToPlayer(vec3 viewPos) {
    return mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
}
vec3 viewDirToWorld(vec3 v) {
    return mat3(gbufferModelViewInverse) * v;
}

// Lightmap coordinates in [0,1] (x = block light, y = sky light)
#ifdef VSH
vec2 getLightmapCoord() {
    vec2 lm = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    return clamp((lm - 0.03125) * 1.06667, 0.0, 1.0);
}
#endif
