#version 330 compatibility

#define VSH
#define WORLD_END
#define PROG_ENTITIES

#include "/program/gbuffers_lit.glsl"
