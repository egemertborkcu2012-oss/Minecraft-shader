#version 330 compatibility

#define FSH
#define WORLD_END
#define PROG_EMISSIVE

#include "/program/gbuffers_simple.glsl"
