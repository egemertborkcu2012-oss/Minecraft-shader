#version 330 compatibility

#define VSH
#define WORLD_END

#include "/program/composite3.glsl"
