#version 330 compatibility

#define VSH
#define WORLD_END
#define PROG_EMISSIVE

#include "/program/gbuffers_simple.glsl"
