#version 330 compatibility

#define FSH
#define WORLD_END
#define PROG_DAMAGED

#include "/program/gbuffers_simple.glsl"
