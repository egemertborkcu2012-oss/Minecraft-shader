#version 330 compatibility

#define VSH
#define WORLD_END
#define PROG_DAMAGED

#include "/program/gbuffers_simple.glsl"
