#version 330 compatibility

#define VSH
#define WORLD_END
#define PROG_SKYTEXTURED

#include "/program/gbuffers_simple.glsl"
