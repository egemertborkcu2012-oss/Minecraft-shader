#version 330 compatibility

#define VSH
#define WORLD_END
#define PROG_PARTICLES

#include "/program/gbuffers_lit.glsl"
