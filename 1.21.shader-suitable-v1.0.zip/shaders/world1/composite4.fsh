#version 330 compatibility

#define FSH
#define WORLD_END

#include "/program/composite4.glsl"
