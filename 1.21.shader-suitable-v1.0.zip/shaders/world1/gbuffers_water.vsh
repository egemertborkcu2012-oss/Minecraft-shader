#version 330 compatibility

#define VSH
#define WORLD_END
#define PROG_WATER

#include "/program/gbuffers_translucent.glsl"
