#version 330 compatibility

#define FSH
#define WORLD_END
#define PROG_SKYTEXTURED

#include "/program/gbuffers_simple.glsl"
