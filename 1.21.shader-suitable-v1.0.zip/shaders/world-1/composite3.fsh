#version 330 compatibility

#define FSH
#define WORLD_NETHER

#include "/program/composite3.glsl"
