#version 330 compatibility

#define FSH
#define WORLD_NETHER
#define PROG_SKYTEXTURED

#include "/program/gbuffers_simple.glsl"
