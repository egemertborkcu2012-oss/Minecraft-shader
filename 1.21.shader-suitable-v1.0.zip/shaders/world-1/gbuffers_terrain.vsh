#version 330 compatibility

#define VSH
#define WORLD_NETHER
#define PROG_TERRAIN

#include "/program/gbuffers_lit.glsl"
