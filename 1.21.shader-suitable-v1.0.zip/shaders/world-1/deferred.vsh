#version 330 compatibility

#define VSH
#define WORLD_NETHER

#include "/program/deferred.glsl"
