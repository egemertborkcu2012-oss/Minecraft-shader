#version 330 compatibility

#define VSH
#define WORLD_NETHER
#define PROG_HAND

#include "/program/gbuffers_lit.glsl"
