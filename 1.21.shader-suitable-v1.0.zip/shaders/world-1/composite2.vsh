#version 330 compatibility

#define VSH
#define WORLD_NETHER

#include "/program/composite2.glsl"
