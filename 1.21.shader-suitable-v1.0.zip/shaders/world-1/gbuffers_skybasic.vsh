#version 330 compatibility

#define VSH
#define WORLD_NETHER
#define PROG_SKYBASIC

#include "/program/gbuffers_simple.glsl"
