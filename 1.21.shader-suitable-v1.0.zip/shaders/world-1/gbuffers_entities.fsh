#version 330 compatibility

#define FSH
#define WORLD_NETHER
#define PROG_ENTITIES

#include "/program/gbuffers_lit.glsl"
