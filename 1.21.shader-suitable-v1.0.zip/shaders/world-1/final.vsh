#version 330 compatibility

#define VSH
#define WORLD_NETHER

#include "/program/final.glsl"
