#version 330 compatibility

#define FSH
#define WORLD_NETHER
#define PROG_WEATHER

#include "/program/gbuffers_overlay.glsl"
