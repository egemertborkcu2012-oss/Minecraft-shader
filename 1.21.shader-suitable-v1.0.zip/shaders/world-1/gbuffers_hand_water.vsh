#version 330 compatibility

#define VSH
#define WORLD_NETHER
#define PROG_HAND_WATER

#include "/program/gbuffers_translucent.glsl"
