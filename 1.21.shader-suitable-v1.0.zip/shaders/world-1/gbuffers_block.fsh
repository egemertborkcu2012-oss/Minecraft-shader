#version 330 compatibility

#define FSH
#define WORLD_NETHER
#define PROG_BLOCK

#include "/program/gbuffers_lit.glsl"
