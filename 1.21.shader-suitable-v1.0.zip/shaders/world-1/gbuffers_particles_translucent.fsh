#version 330 compatibility

#define FSH
#define WORLD_NETHER
#define PROG_TRANSLUCENT_PARTICLES

#include "/program/gbuffers_overlay.glsl"
