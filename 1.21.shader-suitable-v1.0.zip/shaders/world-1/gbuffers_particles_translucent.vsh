#version 330 compatibility

#define VSH
#define WORLD_NETHER
#define PROG_TRANSLUCENT_PARTICLES

#include "/program/gbuffers_overlay.glsl"
