#version 330 compatibility

#define VSH
#define WORLD_OVERWORLD

#include "/program/composite2.glsl"
