#version 330 compatibility

#define FSH
#define WORLD_OVERWORLD

#include "/program/deferred.glsl"
