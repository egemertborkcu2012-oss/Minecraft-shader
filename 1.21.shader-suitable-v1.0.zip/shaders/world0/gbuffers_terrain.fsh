#version 330 compatibility

#define FSH
#define WORLD_OVERWORLD
#define PROG_TERRAIN

#include "/program/gbuffers_lit.glsl"
