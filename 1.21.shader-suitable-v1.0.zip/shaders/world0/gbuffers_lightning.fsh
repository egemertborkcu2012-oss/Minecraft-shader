#version 330 compatibility

#define FSH
#define WORLD_OVERWORLD
#define PROG_LIGHTNING

#include "/program/gbuffers_simple.glsl"
