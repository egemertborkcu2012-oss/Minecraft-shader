#version 330 compatibility

#define FSH
#define WORLD_OVERWORLD
#define PROG_HAND

#include "/program/gbuffers_lit.glsl"
