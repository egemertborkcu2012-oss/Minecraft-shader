#version 330 compatibility

#define FSH
#define WORLD_OVERWORLD
#define PROG_WATER

#include "/program/gbuffers_translucent.glsl"
