#version 330 compatibility

#define VSH
#define WORLD_OVERWORLD
#define PROG_SKYTEXTURED

#include "/program/gbuffers_simple.glsl"
