#version 330 compatibility

#define VSH
#define WORLD_OVERWORLD
#define PROG_WEATHER

#include "/program/gbuffers_overlay.glsl"
