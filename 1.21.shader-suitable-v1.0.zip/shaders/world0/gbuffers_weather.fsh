#version 330 compatibility

#define FSH
#define WORLD_OVERWORLD
#define PROG_WEATHER

#include "/program/gbuffers_overlay.glsl"
