#version 330 compatibility

#define VSH
#define WORLD_OVERWORLD
#define PROG_CLOUDS

#include "/program/gbuffers_simple.glsl"
