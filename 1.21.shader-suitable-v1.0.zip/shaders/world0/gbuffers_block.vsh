#version 330 compatibility

#define VSH
#define WORLD_OVERWORLD
#define PROG_BLOCK

#include "/program/gbuffers_lit.glsl"
