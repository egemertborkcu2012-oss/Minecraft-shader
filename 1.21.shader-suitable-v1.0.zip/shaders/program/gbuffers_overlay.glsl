/*
    YAKAMOZ SHADERS - gbuffers_overlay.glsl
      PROG_WEATHER                gbuffers_weather (rain & snow)
      PROG_TRANSLUCENT_PARTICLES  gbuffers_particles_translucent

    These are drawn into the premultiplied translucent layer (colortex3)
    so they stay in front of water after the composite pass resolves it.
*/

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/common.glsl"
#include "/lib/materials.glsl"
#ifdef WORLD_OVERWORLD
#define SHADOW_LOOKUP
#endif
#include "/lib/atmosphere.glsl"
#include "/lib/shadows.glsl"
#include "/lib/waves.glsl"
#include "/lib/lighting.glsl"

// ================================================================
#ifdef VSH

out vec2 texcoord;
out vec2 lmcoord;
out vec4 glcolor;
out vec3 playerPos;
flat out vec3 directCol;
flat out vec3 ambientCol;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = getLightmapCoord();
    glcolor  = gl_Color;
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    playerPos = (gbufferModelViewInverse * viewPos).xyz;
    gl_Position = gl_ProjectionMatrix * viewPos;
    getLightColors(directCol, ambientCol);
}

#endif
// ================================================================
#ifdef FSH

in vec2 texcoord;
in vec2 lmcoord;
in vec4 glcolor;
in vec3 playerPos;
flat in vec3 directCol;
flat in vec3 ambientCol;

uniform sampler2D gtexture;

/* RENDERTARGETS: 3 */
layout(location = 0) out vec4 outColor;

void main() {
    vec4 albedo = texture(gtexture, texcoord) * glcolor;
    if (albedo.a < 0.02) discard;
    vec3 srgb = albedo.rgb;
    albedo.rgb = toLinear(albedo.rgb);

#ifdef PROG_WEATHER
    // rain streaks catch sky light and nearby torches, but stay subtle
    vec3 light = ambientCol * (0.6 + 0.6 * lmcoord.y) + directCol * 0.15 + blockLight(lmcoord.x);
    vec3 color = albedo.rgb * light;
    outColor = vec4(color, albedo.a * 0.55);
#else
    vec3 normal = -normalize(playerPos + vec3(0.0, 1e-4, 0.0));
    float dither = gradientNoise(gl_FragCoord.xy);
    vec3 color = shadeSurface(albedo.rgb, normal, lmcoord, playerPos, 1.0, 0.0, 0.0, directCol, ambientCol, dither);
    if (lmcoord.x > 0.98 && lmcoord.y > 0.98) color += albedo.rgb * 2.5 * smoothstep(0.35, 0.9, maxOf(srgb)) * EMISSIVE_BRIGHTNESS;
    outColor = vec4(color, albedo.a);
#endif
}

#endif
