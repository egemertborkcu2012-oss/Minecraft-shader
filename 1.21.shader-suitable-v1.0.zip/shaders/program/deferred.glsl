/*
    YAKAMOZ SHADERS - deferred.glsl
    Runs after all opaque geometry. Fills every sky pixel with the
    procedural sky (atmosphere, sun, stars, milky way, clouds) and keeps
    the vanilla moon texture that gbuffers_skytextured drew underneath.
*/

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/common.glsl"
#include "/lib/atmosphere.glsl"

// ================================================================
#ifdef VSH

out vec2 texcoord;
flat out vec3 cloudLight;
flat out vec3 cloudAmbient;

void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
#ifdef WORLD_OVERWORLD
    computeCloudLight(cloudLight, cloudAmbient);
#else
    cloudLight = vec3(0.0);
    cloudAmbient = vec3(0.0);
#endif
}

#endif
// ================================================================
#ifdef FSH

in vec2 texcoord;
flat in vec3 cloudLight;
flat in vec3 cloudAmbient;

uniform sampler2D colortex0;
uniform sampler2D depthtex0;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

#ifdef WORLD_END
vec3 endSky(vec3 dir) {
    float h = dir.y * 0.5 + 0.5;
    vec3 col = mix(vec3(0.010, 0.006, 0.016), vec3(0.030, 0.018, 0.045), h);
    // slow drifting nebula
    vec2 p = vec2(atan(dir.z, dir.x) * 2.0, dir.y * 3.0);
    float n = valueNoise(p * 2.0 + frameTimeCounter * 0.01) * 0.6 + valueNoise(p * 5.0) * 0.4;
    col += vec3(0.06, 0.02, 0.09) * smoothstep(0.45, 0.9, n) * (1.0 - abs(dir.y));
    vec3 q = dir * 180.0;
    vec3 h3 = hash33(floor(q));
    if (h3.x < 0.04) {
        float d = length(fract(q) - 0.5 - (h3 - 0.5) * 0.4);
        col += mix(vec3(0.8, 0.6, 1.0), vec3(0.6, 0.8, 1.0), h3.y) * smoothstep(0.3, 0.0, d) * pow(h3.z, 4.0) * 0.4;
    }
    return col;
}
#endif

void main() {
    vec3 color = texture(colortex0, texcoord).rgb;
    float depth = texture(depthtex0, texcoord).r;

    if (depth >= 1.0) {
        vec3 dir = normalize(viewDirToWorld(normalize(screenToView(texcoord, 1.0))));
#if defined WORLD_OVERWORLD
        float cloudAlpha;
        vec3 sky = renderSky(dir, cloudLight, cloudAmbient, true, 6, cloudAlpha);
        // vanilla moon disc (already in colortex0) is hidden by clouds and haze
        float horizon = smoothstep(-0.02, 0.12, dir.y);
        color = sky + color * (1.0 - cloudAlpha) * horizon * (1.0 - rainStrength);
#elif defined WORLD_END
        color = endSky(dir);
#else
        color = toLinear(fogColor) * 0.6;
#endif
    }

    outColor = vec4(color, 1.0);
}

#endif
