/*
    YAKAMOZ SHADERS - gbuffers_lit.glsl
    Opaque / cutout geometry, forward lit:
      PROG_TERRAIN    gbuffers_terrain   (waving plants, materials, puddles)
      PROG_BLOCK      gbuffers_block     (block entities)
      PROG_ENTITIES   gbuffers_entities  (mobs, item entities, hurt flash)
      PROG_HAND       gbuffers_hand      (first person hand / held items)
      PROG_PARTICLES  gbuffers_textured(_lit) (particles)

    Outputs: colortex0 = lit HDR colour
             colortex1 = world normal (oct) + sky light
             colortex2 = material id, smoothness/metal, block light
*/

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/common.glsl"
#include "/lib/materials.glsl"
#ifdef WORLD_OVERWORLD
#define SHADOW_LOOKUP
#endif
#include "/lib/atmosphere.glsl"
#include "/lib/shadows.glsl"
#include "/lib/waves.glsl"
#include "/lib/lighting.glsl"

// ================================================================
#ifdef VSH

#ifdef PROG_TERRAIN
#include "/lib/waving.glsl"
in vec2 mc_Entity;
in vec2 mc_midTexCoord;
#endif

out vec2 texcoord;
out vec2 lmcoord;
out vec4 glcolor;
out vec3 playerPos;
out vec3 worldNormal;
flat out int blockId;
flat out vec3 directCol;
flat out vec3 ambientCol;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = getLightmapCoord();
    glcolor  = gl_Color;
    blockId  = 0;

    worldNormal = mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * gl_Normal);
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    playerPos = (gbufferModelViewInverse * viewPos).xyz;

#ifdef PROG_TERRAIN
    blockId = int(mc_Entity.x + 0.5);
    bool topVertex = gl_MultiTexCoord0.t < mc_midTexCoord.t;
    playerPos += waveVertex(playerPos + cameraPosition, blockId, topVertex, lmcoord.y);
    gl_Position = gl_ProjectionMatrix * (gbufferModelView * vec4(playerPos, 1.0));
#else
    gl_Position = gl_ProjectionMatrix * viewPos;
#endif

#ifdef PROG_PARTICLES
    worldNormal = -normalize(playerPos + vec3(0.0, 1e-4, 0.0));
#endif

    getLightColors(directCol, ambientCol);
}

#endif
// ================================================================
#ifdef FSH

in vec2 texcoord;
in vec2 lmcoord;
in vec4 glcolor;
in vec3 playerPos;
in vec3 worldNormal;
flat in int blockId;
flat in vec3 directCol;
flat in vec3 ambientCol;

uniform sampler2D gtexture;
#ifdef PROG_ENTITIES
uniform vec4 entityColor;
uniform int currentRenderedItemId;
#endif
#ifdef PROG_BLOCK
uniform int blockEntityId;
#endif
#ifdef PROG_HAND
uniform int currentRenderedItemId;
#endif

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outNormal;
layout(location = 2) out vec4 outMaterial;

// Emission for held / dropped items: only the glowing part of the sprite
float itemEmission(int id, vec3 srgb) {
    if (id == ID_LAVA) {
        // lava bucket: only the orange lava texels, not the metal
        return 4.0 * smoothstep(0.25, 0.55, srgb.r - srgb.b) * smoothstep(0.5, 0.8, srgb.r) * EMISSIVE_BRIGHTNESS;
    }
    return blockEmission(id, srgb);
}

void main() {
    vec4 albedo = texture(gtexture, texcoord) * glcolor;
#ifdef PROG_ENTITIES
    albedo.rgb = mix(albedo.rgb, entityColor.rgb, entityColor.a);
#endif
    if (albedo.a < 0.1) discard;

    vec3 srgb = albedo.rgb;
    albedo.rgb = toLinear(albedo.rgb);

    vec3 normal = normalize(worldNormal);
    if (!gl_FrontFacing) normal = -normal;

    float subsurface = 0.0;
    float smoothness = 0.0;
    float metalness  = 0.0;
    float emission   = 0.0;
    float material   = MAT_DEFAULT;
    vec2  lm = lmcoord;

#if defined PROG_TERRAIN || defined PROG_BLOCK
#ifdef PROG_BLOCK
    int id = blockEntityId;
#else
    int id = blockId;
#endif
    if (id == ID_PLANT || id == ID_TALL_LOWER || id == ID_TALL_UPPER || id == ID_VINE) {
        subsurface = 1.0;
        material = MAT_FOLIAGE;
        normal = vec3(0.0, 1.0, 0.0);        // grass blades read like the ground they grow on
    } else if (id == ID_LEAVES || id == ID_LILY_PAD) {
        subsurface = 0.8;
        material = MAT_FOLIAGE;
    } else if (id == ID_POLISHED) {
        smoothness = 0.72;
    } else if (id == ID_METAL) {
        smoothness = 0.80;
        metalness = 1.0;
    } else if (id == ID_GEM) {
        smoothness = 0.86;
    } else if (id == ID_GLASS) {
        smoothness = 0.95;
    } else if (id == ID_ICE) {
        smoothness = 0.92;
    }

    emission = blockEmission(id, srgb);
    if (id == ID_LAVA) {
        // slow "breathing" heat pattern across lava lakes
        vec2 wp = (playerPos + cameraPosition).xz;
        float heat = valueNoise(wp * 0.45 + frameTimeCounter * 0.15) * 0.6 + valueNoise(wp * 1.3 - frameTimeCounter * 0.25) * 0.4;
        emission *= 0.75 + 0.5 * heat;
        material = MAT_LAVA;
        lm.x = 1.0;
    } else if (emission > 0.0) {
        material = MAT_EMISSIVE;
    }
#endif

#ifdef PROG_TERRAIN
#ifdef RAIN_PUDDLES
    // rain makes exposed, upward facing ground wet; puddles collect in noisy patches
    if (wetness > 0.001 && subsurface < 0.5) {
        vec3 wp = playerPos + cameraPosition;
        float exposed = smoothstep(0.88, 0.97, lm.y);
        float up = smoothstep(0.6, 0.95, normal.y);
        float puddle = smoothstep(0.42, 0.62, valueNoise(wp.xz * 0.32) * 0.7 + valueNoise(wp.xz * 1.1) * 0.3);
        float wet = wetness * exposed * mix(0.25, 1.0, up * puddle);
        albedo.rgb *= 1.0 - wet * 0.35;
        smoothness = max(smoothness, wet * 0.9 * up + wet * 0.35);
    }
#endif
#endif

#ifdef PROG_ENTITIES
    material = MAT_ENTITY;
    emission = itemEmission(currentRenderedItemId, srgb);
#endif

#ifdef PROG_HAND
    material = MAT_HAND;
    emission = itemEmission(currentRenderedItemId, srgb);
#endif

#ifdef PROG_PARTICLES
    material = MAT_PARTICLE;
    subsurface = 1.0;
    // flames, lava drips, glow particles are drawn full-bright
    if (lm.x > 0.98 && lm.y > 0.98) emission = 2.5 * smoothstep(0.35, 0.9, maxOf(srgb)) * EMISSIVE_BRIGHTNESS;
#endif

    float dither = gradientNoise(gl_FragCoord.xy);
    vec3 color = shadeSurface(albedo.rgb, normal, lm, playerPos, subsurface,
                              smoothness, metalness, directCol, ambientCol, dither);
    color += albedo.rgb * emission;

    outColor    = vec4(color, albedo.a);
    outNormal   = vec4(encodeNormal(normal), lm.y, 1.0);
    outMaterial = vec4(material / 255.0, metalness * 0.5 + min(smoothness, 0.99) * 0.5, lm.x, 1.0);
}

#endif
