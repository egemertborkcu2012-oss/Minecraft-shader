/*
    YAKAMOZ SHADERS - composite4.glsl  (bloom: vertical blur inside each tile)
*/

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/common.glsl"
#include "/lib/bloom.glsl"

// ================================================================
#ifdef VSH

out vec2 texcoord;

void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
}

#endif
// ================================================================
#ifdef FSH

in vec2 texcoord;

uniform sampler2D colortex7;

/* RENDERTARGETS: 7 */
layout(location = 0) out vec4 outBloom;

void main() {
    vec3 result = vec3(0.0);
#ifdef BLOOM
    float px = 1.0 / viewHeight;
    for (int i = 0; i < BLOOM_TILES; i++) {
        float s = bloomTileScale(i);
        vec2 off = bloomTileOffset(i);
        vec2 local = (texcoord - off) / s;
        if (all(greaterThanEqual(local, vec2(0.0))) && all(lessThanEqual(local, vec2(1.0)))) {
            float lo = off.y + px * 0.5;
            float hi = off.y + s - px * 0.5;
            vec3 sum = vec3(0.0);
            float wsum = 0.0;
            for (int k = -4; k <= 4; k++) {
                float w = bloomWeight(k);
                vec2 suv = vec2(texcoord.x, clamp(texcoord.y + float(k) * px, lo, hi));
                sum += texture(colortex7, suv).rgb * w;
                wsum += w;
            }
            result = sum / wsum;
            break;
        }
    }
#endif
    outBloom = vec4(result, 1.0);
}

#endif
