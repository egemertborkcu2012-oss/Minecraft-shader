/*
    YAKAMOZ SHADERS - final.glsl
    Bloom resolve, eye adaptation, tonemapping and colour grading.

    Eye adaptation uses eyeBrightnessSmooth (already time-smoothed by
    Iris): caves open up, torch-lit rooms calm down, nights stay dark
    but readable. Very dark tones shift towards blue (night vision of
    the human eye) for a cold, moonlit feel.
*/

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/common.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/bloom.glsl"
#include "/lib/tonemap.glsl"

// ================================================================
#ifdef VSH

out vec2 texcoord;
flat out float exposure;

void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;

    float eyeSky   = float(eyeBrightnessSmooth.y) / 240.0;
    float eyeBlock = float(eyeBrightnessSmooth.x) / 240.0;
#if defined WORLD_OVERWORLD
    float day = smoothstep(-0.15, 0.06, sunDirection().y);
    float outdoor = mix(3.0, 0.82, day) * mix(1.0, 1.3, rainStrength * day);
    float e = mix(1.7, outdoor, smoothstep(0.05, 0.75, eyeSky));
    e /= 1.0 + eyeBlock * eyeBlock * 0.55 * (1.0 - day * eyeSky);
#elif defined WORLD_NETHER
    float e = 1.5 / (1.0 + eyeBlock * eyeBlock * 0.4);
#else
    float e = 1.9 / (1.0 + eyeBlock * eyeBlock * 0.4);
#endif
    if (isEyeInWater == 1) e *= 1.15;
    exposure = e * EXPOSURE;
}

#endif
// ================================================================
#ifdef FSH

in vec2 texcoord;
flat in float exposure;

uniform sampler2D colortex0;
uniform sampler2D colortex7;

layout(location = 0) out vec4 fragColor;

vec3 resolveBloom(vec2 uv) {
    vec3 sum = vec3(0.0);
    float wsum = 0.0;
    vec2 res = vec2(viewWidth, viewHeight);
    for (int i = 0; i < BLOOM_TILES; i++) {
        float s = bloomTileScale(i);
        vec2 halfTexel = 0.5 / (res * s);
        vec2 local = clamp(uv, halfTexel, 1.0 - halfTexel);
        float w = 1.0 + float(i) * 0.15;
        sum += texture(colortex7, bloomTileOffset(i) + local * s).rgb * w;
        wsum += w;
    }
    return sum / wsum;
}

void main() {
    vec3 color = texture(colortex0, texcoord).rgb;

#ifdef BLOOM
    vec3 bloom = resolveBloom(texcoord);
    color = mix(color, bloom, 0.09 * BLOOM_STRENGTH);
    // a little extra glow for very bright light sources (lava, flames, the sun)
    color += max(bloom - 1.5, vec3(0.0)) * 0.03 * BLOOM_STRENGTH;
#endif

    color *= exposure;

    // scotopic shift: very dark areas turn desaturated blue, like real night vision
    float lum = luma(color);
    float scotopic = (1.0 - smoothstep(0.0005, 0.05, lum)) * 0.55;
    color = mix(color, lum * vec3(0.62, 0.78, 1.15), scotopic);

    color = tonemap(color);

    // saturation & contrast in display space
    float l = luma(color);
    color = max(mix(vec3(l), color, SATURATION), vec3(0.0));
    color = linearToSrgb(color);
    color = sat((color - 0.5) * CONTRAST + 0.5);

    // vignette
    vec2 v = (texcoord - 0.5) * vec2(aspectRatio, 1.0);
    color *= 1.0 - VIGNETTE * pow(sat(length(v) * 0.9), 2.4);

    // dither away banding
    color += (gradientNoise(gl_FragCoord.xy) - 0.5) / 255.0;

    fragColor = vec4(color, 1.0);
}

#endif
