/*
    YAKAMOZ SHADERS - composite1.glsl  (volumetric light / god rays)

    Marches the shadow map along each view ray. Because the shadow
    projection is affine, the ray is interpolated directly in shadow clip
    space. Height-dependent density keeps the haze in valleys; under
    water the shafts pick up the caustic pattern stored in shadowcolor0.
*/

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/common.glsl"
#include "/lib/materials.glsl"
#define SHADOW_LOOKUP
#include "/lib/atmosphere.glsl"
#include "/lib/shadows.glsl"
#include "/lib/water.glsl"

// ================================================================
#ifdef VSH

out vec2 texcoord;
flat out vec3 directCol;

void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    vec3 ambient;
    computeLightColors(directCol, ambient);
}

#endif
// ================================================================
#ifdef FSH

in vec2 texcoord;
flat in vec3 directCol;

uniform sampler2D depthtex0;

/* RENDERTARGETS: 6 */
layout(location = 0) out vec4 outLight;

void main() {
    vec3 result = vec3(0.0);
#ifdef VOLUMETRIC_LIGHT
    float depth = texture(depthtex0, texcoord).r;
    vec3 viewPos = screenToView(texcoord, depth);
    vec3 origin = gbufferModelViewInverse[3].xyz;
    vec3 endPos = viewToPlayer(viewPos);
    vec3 ray = endPos - origin;
    float dist = length(ray);
    vec3 dirW = ray / max(dist, 1e-4);

    bool underwater = isEyeInWater == 1;
    float maxDist = underwater ? 48.0 : shadowDistance * 0.9;
    float rayLen = min(dist, maxDist);

    vec3 L = lightDirection();
    float mu = dot(dirW, L);
    float eyeSky = float(eyeBrightnessSmooth.y) / 240.0;

    if (maxOf(directCol) > 1e-5 && isEyeInWater < 2) {
        vec3 clipA = shadowClipPos(origin);
        vec3 clipB = shadowClipPos(origin + dirW * rayLen);
        float dither = gradientNoise(gl_FragCoord.xy);
        vec3 absorb = waterAbsorption(DEFAULT_WATER_TINT);

        vec3 accum = vec3(0.0);
        for (int i = 0; i < VL_SAMPLES; i++) {
            float t = (float(i) + dither) / float(VL_SAMPLES);
            vec3 vis = shadowVisibilityAt(mix(clipA, clipB, t), underwater);
            if (underwater) {
                vis *= exp(-absorb * (t * rayLen));
            } else {
                float y = cameraPosition.y + origin.y + dirW.y * rayLen * t;
                vis *= exp(-max(y - 63.0, 0.0) * 0.012);
            }
            accum += vis;
        }
        accum /= float(VL_SAMPLES);

        if (underwater) {
            float phase = phaseHG(mu, 0.55) * 0.7 + 0.3;
            result = accum * directCol * waterScatterColor(DEFAULT_WATER_TINT) * phase * (rayLen * 0.25);
        } else {
            float sunY = sunDirection().y;
            float density = 0.00045 + rainStrength * 0.0025;
#ifdef MORNING_MIST
            density += 0.0016 * exp(-sq((sunY - 0.08) * 7.0)) * (1.0 - rainStrength);
#endif
            float phase = phaseHG(mu, 0.72) * 0.55 + phaseHG(mu, -0.2) * 0.15 + 0.3;
            result = accum * directCol * (phase * density * rayLen * FOG_DENSITY);
            result *= mix(0.25, 1.0, smoothstep(0.1, 0.8, eyeSky));
        }
        result *= VL_STRENGTH;
    }
#endif
    outLight = vec4(result, 1.0);
}

#endif
