/*
    YAKAMOZ SHADERS - composite.glsl  (water, glass & reflections)

    For every translucent pixel the opaque scene below is fetched with a
    wave-driven refraction offset, then absorbed and scattered by the
    water column between the surface and the ground (biome tinted).
    Reflections use a screen-space ray march; rays that leave the screen
    or hit nothing fade smoothly into the procedural sky. When the sky is
    not visible (caves), reflections fall back to the warm glow of nearby
    block light, so lava and torches tint water and polished floors.
    Sun and moon glints use a GGX lobe on the animated wave normals.
*/

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/common.glsl"
#include "/lib/materials.glsl"
#ifdef WORLD_OVERWORLD
#define SHADOW_LOOKUP
#endif
#include "/lib/atmosphere.glsl"
#include "/lib/shadows.glsl"
#include "/lib/waves.glsl"
#include "/lib/lighting.glsl"
#include "/lib/water.glsl"

// ================================================================
#ifdef VSH

out vec2 texcoord;
flat out vec3 directCol;
flat out vec3 ambientCol;
flat out vec3 cloudLight;
flat out vec3 cloudAmbient;

void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    getLightColors(directCol, ambientCol);
#ifdef WORLD_OVERWORLD
    computeCloudLight(cloudLight, cloudAmbient);
#else
    cloudLight = vec3(0.0);
    cloudAmbient = vec3(0.0);
#endif
}

#endif
// ================================================================
#ifdef FSH

in vec2 texcoord;
flat in vec3 directCol;
flat in vec3 ambientCol;
flat in vec3 cloudLight;
flat in vec3 cloudAmbient;

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex3;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;

/*
    Render target setup (read by Iris from this comment block)
    const int colortex0Format = RGBA16F;
    const int colortex1Format = RGBA16;
    const int colortex2Format = RGBA8;
    const int colortex3Format = RGBA16F;
    const int colortex4Format = RGBA16;
    const int colortex5Format = RGBA16;
    const int colortex6Format = RGBA16F;
    const int colortex7Format = RGBA16F;
    const vec4 colortex0ClearColor = vec4(0.0, 0.0, 0.0, 1.0);
    const vec4 colortex1ClearColor = vec4(0.5, 0.5, 0.0, 0.0);
    const vec4 colortex2ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
    const vec4 colortex3ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
    const vec4 colortex4ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
    const vec4 colortex5ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
    const vec4 colortex6ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
    const vec4 colortex7ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
*/

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

// ---------------------------------------------------------------
//  Screen-space reflections
// ---------------------------------------------------------------
#if SSR_QUALITY == 1
const int   SSR_STEPS  = 16;
const int   SSR_REFINE = 4;
const float SSR_GROWTH = 1.32;
#elif SSR_QUALITY == 2
const int   SSR_STEPS  = 28;
const int   SSR_REFINE = 5;
const float SSR_GROWTH = 1.19;
#else
const int   SSR_STEPS  = 48;
const int   SSR_REFINE = 6;
const float SSR_GROWTH = 1.11;
#endif

// rgb = reflected scene colour, a = confidence (0 = use the sky / environment)
vec4 traceReflection(vec3 viewPos, vec3 rayDir, float dither) {
#if SSR_QUALITY > 0
    float stepLen = 0.35 + length(viewPos) * 0.02;
    vec3 stepVec = rayDir * stepLen;
    vec3 pos = viewPos + stepVec * (0.25 + 0.75 * dither);
    vec3 prev = viewPos;

    for (int i = 0; i < SSR_STEPS; i++) {
        vec3 sp = viewToScreen(pos);
        if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0 || sp.z >= 1.0) break;

        float sceneDepth = texture(depthtex1, sp.xy).r;
        if (sceneDepth < 1.0) {
            float sceneZ = screenToView(sp.xy, sceneDepth).z;
            float diff = sceneZ - pos.z;            // > 0: the ray went behind the surface
            if (diff > 0.0 && diff < length(stepVec) * 2.2 + 0.25) {
                // binary search refinement
                vec3 a = prev;
                vec3 b = pos;
                for (int j = 0; j < SSR_REFINE; j++) {
                    vec3 m = (a + b) * 0.5;
                    vec3 msp = viewToScreen(m);
                    float mz = screenToView(msp.xy, texture(depthtex1, msp.xy).r).z;
                    if (mz - m.z > 0.0) b = m; else a = m;
                }
                vec3 hit = viewToScreen(b);
                float hitMat = texture(colortex2, hit.xy).r * 255.0;
                if (abs(hitMat - MAT_HAND) < 0.5) break;
                vec2 edge = min(hit.xy, 1.0 - hit.xy);
                float fade = sat(min(edge.x, edge.y) * 10.0);
                return vec4(texture(colortex0, hit.xy).rgb, fade);
            }
        }
        prev = pos;
        stepVec *= SSR_GROWTH;
        pos += stepVec;
    }
#endif
    return vec4(0.0);
}

// What a reflection shows when the ray misses the screen
vec3 environmentReflection(vec3 dirW, float skyLight, float blockLM) {
    vec3 env = vec3(0.0);
#if defined WORLD_OVERWORLD
    float cloudAlpha;
    vec3 sky = renderSky(dirW, cloudLight, cloudAmbient, false, 4, cloudAlpha);
    env = sky * (skyLight * skyLight);
#elif defined WORLD_NETHER
    env = toLinear(fogColor) * 0.45;
#else
    env = vec3(0.035, 0.025, 0.055);
#endif
    // the warm glow of nearby lava / torches, visible even when they are off screen
    env += BLOCKLIGHT_COLOR * (blockLightFalloff(blockLM) * BLOCKLIGHT_INTENSITY * 0.55 * BLOCKLIGHT_BRIGHTNESS);
    return env;
}

void main() {
    vec2 uv = texcoord;
    vec3 color   = texture(colortex0, uv).rgb;
    float depth0 = texture(depthtex0, uv).r;
    float depth1 = texture(depthtex1, uv).r;
    vec4 trans   = texture(colortex3, uv);
    vec4 tdata   = texture(colortex4, uv);
    float dither = gradientNoise(gl_FragCoord.xy);

    float tmat, tsky;
    unpackMatSky(tdata.b, tmat, tsky);

    vec3 viewPos0 = screenToView(uv, depth0);
    vec3 viewDir  = normalize(viewPos0);
    vec3 dirW     = viewDirToWorld(viewDir);

    bool translucent = depth0 < depth1 && tmat > 0.5;

    if (translucent) {
        vec3 nW = decodeNormal(tdata.rg);
        vec3 nV = normalize(mat3(gbufferModelView) * nW);
        vec4 extra = texture(colortex5, uv);
        float blockLM = extra.r;
        vec3 playerPos0 = viewToPlayer(viewPos0);

        // light reaching the surface (sun/moon, sky, block light)
        vec3 sunAtSurface = vec3(0.0);
#ifdef WORLD_OVERWORLD
        vec4 sm = sampleShadow(playerPos0, vec3(0.0, 1.0, 0.0), 1.0, dither, 0.0);
        sunAtSurface = mix(vec3(smoothstep(0.75, 0.95, tsky)), sm.rgb, sm.a) * cloudShadow(playerPos0 + cameraPosition);
        sunAtSurface *= smoothstep(0.0, 0.12, tsky);
#endif

        if (tmat < 1.5) {
            // ======================= WATER =======================
            vec3 tint = unpackColor565(extra.g);
            vec2 refrUV = uv;
#ifdef WATER_REFRACTION
            if (abs(nW.y) > 0.5) {
                vec3 dnV = mat3(gbufferModelView) * vec3(nW.x, 0.0, nW.z);
                float thick0 = length(screenToView(uv, depth1) - viewPos0);
                vec2 offset = dnV.xy * (0.25 * REFRACTION_STRENGTH) * sat(thick0 * 0.6) / (1.0 + length(viewPos0) * 0.08);
                vec2 cand = clamp(uv + offset, vec2(0.001), vec2(0.999));
                float cDepth0 = texture(depthtex0, cand).r;
                float cDepth1 = texture(depthtex1, cand).r;
                float cMat, cSky;
                unpackMatSky(texture(colortex4, cand).b, cMat, cSky);
                if (cDepth1 > cDepth0 && cDepth1 > depth0 && abs(cMat - TMAT_WATER) < 0.5) refrUV = cand;
            }
#endif
            vec3 behind = texture(colortex0, refrUV).rgb;
            float refrDepth = texture(depthtex1, refrUV).r;
            float thickness = refrDepth >= 1.0 ? 256.0 : length(screenToView(refrUV, refrDepth) - viewPos0);

            vec3 waterLight = (directCol * sunAtSurface * 0.5 + ambientCol) * (tsky * tsky) + blockLight(blockLM) * 0.4;
            vec3 waterColor = behind;
            if (isEyeInWater != 1) waterColor = waterVolume(behind, thickness, tint, waterLight);

            // ---- reflection ----
            float NdotV = max(dot(nV, -viewDir), 0.0);
            float fresnel;
            if (isEyeInWater == 1) {
                // from below: Snell's window, total internal reflection outside it
                float sinT2 = 1.7769 * (1.0 - NdotV * NdotV);
                fresnel = sinT2 >= 1.0 ? 1.0 : 0.02 + 0.98 * pow(1.0 - sqrt(1.0 - sinT2), 5.0);
            } else {
                fresnel = 0.02 + 0.98 * pow(1.0 - NdotV, 5.0);
            }

            vec3 reflV = reflect(viewDir, nV);
            vec3 reflW = viewDirToWorld(reflV);
            vec3 env;
            if (isEyeInWater == 1) {
                env = waterVolume(vec3(0.0), 512.0, tint, waterLight);
            } else {
                reflW.y = abs(reflW.y);
                env = environmentReflection(reflW, tsky, blockLM);
            }
            vec4 ssr = traceReflection(viewPos0 + nV * 0.02, reflV, dither);
            vec3 reflection = mix(env, ssr.rgb, ssr.a);
            waterColor = mix(waterColor, reflection, fresnel);

#ifdef WORLD_OVERWORLD
            if (isEyeInWater != 1) {
                // sun glitter by day, the moon's path ("yakamoz") by night
                vec3 Vw = -dirW;
                vec3 sunDir = sunDirection();
                float sunFade  = smoothstep(0.0, 0.06, sunDir.y);
                float moonFade = smoothstep(0.0, 0.06, -sunDir.y);
                vec3 sunCol  = atmTransmittance(sunDir.y) * (SUN_ILLUMINANCE * SUN_BRIGHTNESS) * sunFade;
                vec3 moonCol = MOON_TINT * (MOON_ILLUMINANCE * MOON_BRIGHTNESS * moonPhaseBrightness()) * moonFade * 1.6;
                vec3 glint = sunCol  * specularGGX(nW, Vw,  sunDir, 0.085, vec3(0.02))
                           + moonCol * specularGGX(nW, Vw, -sunDir, 0.11,  vec3(0.02));
                waterColor += glint * sunAtSurface * (1.0 - rainStrength) * SPECULAR_STRENGTH;
            }
#endif
            color = waterColor;
        } else {
            // =================== GLASS / ICE / OTHER ===================
            float NdotV = max(dot(nV, -viewDir), 0.0);
            float fresnel = 0.04 + 0.96 * pow(1.0 - NdotV, 5.0);
            if (tmat < 2.5) {
                vec3 reflV = reflect(viewDir, nV);
                vec3 env = environmentReflection(viewDirToWorld(reflV), tsky, blockLM);
                vec4 ssr = traceReflection(viewPos0 + nV * 0.02, reflV, dither);
                color = mix(color, mix(env, ssr.rgb, ssr.a), fresnel * 0.9);
            }
        }
    } else if (depth1 < 1.0) {
#ifdef SSR_SHINY_BLOCKS
        // ================ POLISHED / METAL / WET BLOCKS ================
        vec4 mdata = texture(colortex2, uv);
        float mat = mdata.r * 255.0;
        float metal = step(0.5, mdata.g);
        float smoothness = (mdata.g - metal * 0.5) * 2.0;
        if (smoothness > 0.1 && abs(mat - MAT_HAND) > 0.5 && abs(mat - MAT_PARTICLE) > 0.5) {
            vec4 ndata = texture(colortex1, uv);
            vec3 nW = decodeNormal(ndata.rg);
            vec3 nV = normalize(mat3(gbufferModelView) * nW);
            float NdotV = max(dot(nV, -viewDir), 0.0);
            vec3 F0 = mix(vec3(0.04), vec3(0.65), metal);
            vec3 F = fresnelSchlick(NdotV, F0) * (smoothness * smoothness);

            // rough surfaces get a jittered (blurry) reflection
            vec3 jitter = (hash33(vec3(gl_FragCoord.xy, 3.0)) - 0.5) * (1.0 - smoothness) * 0.35;
            vec3 nJ = normalize(nV + jitter);
            vec3 reflV = reflect(viewDir, nJ);
            vec3 env = environmentReflection(viewDirToWorld(reflV), ndata.b, mdata.b);
            vec4 ssr = traceReflection(viewPos0 + nV * 0.02, reflV, dither);
            vec3 reflection = mix(env, ssr.rgb, ssr.a);

            vec3 tintCol = mix(vec3(1.0), clamp(color / max(luma(color), 1e-3), 0.0, 2.0), metal);
            color = mix(color, reflection * tintCol, F);
        }
#endif
    }

    // stained glass, rain, translucent particles and held glass on top
    color = color * (1.0 - trans.a) + trans.rgb;

    if (any(isnan(color)) || any(isinf(color))) color = vec3(0.0);
    outColor = vec4(min(color, vec3(30000.0)), 1.0);
}

#endif
