/*
    YAKAMOZ SHADERS - gbuffers_translucent.glsl
      PROG_WATER       gbuffers_water   (water, stained glass, ice, portals...)
      PROG_HAND_WATER  gbuffers_hand_water

    Translucent surfaces never write into colortex0. Their lit colour is
    accumulated (premultiplied) in colortex3 and their surface data in
    colortex4/5, so the composite pass can refract, fog and reflect the
    untouched opaque scene underneath.

    colortex4 = normal (oct) | material + sky light (packed) | 1
    colortex5 = block light  | biome water tint (RGB565)     | 1
*/

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/common.glsl"
#include "/lib/materials.glsl"
#ifdef WORLD_OVERWORLD
#define SHADOW_LOOKUP
#endif
#include "/lib/atmosphere.glsl"
#include "/lib/shadows.glsl"
#include "/lib/waves.glsl"
#include "/lib/lighting.glsl"

// ================================================================
#ifdef VSH

#ifdef PROG_WATER
in vec2 mc_Entity;
#endif

out vec2 texcoord;
out vec2 lmcoord;
out vec4 glcolor;
out vec3 playerPos;
out vec3 worldNormal;
flat out int blockId;
flat out vec3 directCol;
flat out vec3 ambientCol;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = getLightmapCoord();
    glcolor  = gl_Color;
    blockId  = 0;

    worldNormal = mat3(gbufferModelViewInverse) * normalize(gl_NormalMatrix * gl_Normal);
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    playerPos = (gbufferModelViewInverse * viewPos).xyz;

#ifdef PROG_WATER
    blockId = int(mc_Entity.x + 0.5);
#ifdef WATER_VERTEX_WAVES
    if (blockId == ID_WATER && worldNormal.y > 0.5) {
        playerPos.y += waterDisplacement(playerPos.xz + cameraPosition.xz);
    }
#endif
    gl_Position = gl_ProjectionMatrix * (gbufferModelView * vec4(playerPos, 1.0));
#else
    gl_Position = gl_ProjectionMatrix * viewPos;
#endif

    getLightColors(directCol, ambientCol);
}

#endif
// ================================================================
#ifdef FSH

in vec2 texcoord;
in vec2 lmcoord;
in vec4 glcolor;
in vec3 playerPos;
in vec3 worldNormal;
flat in int blockId;
flat in vec3 directCol;
flat in vec3 ambientCol;

uniform sampler2D gtexture;

#ifdef PROG_WATER
/* RENDERTARGETS: 4,3,5 */
layout(location = 0) out vec4 outData;      // colortex4 (alpha 1 -> always overwrites)
layout(location = 1) out vec4 outColor;     // colortex3 (premultiplied translucency)
layout(location = 2) out vec4 outExtra;     // colortex5
#else
/* RENDERTARGETS: 3,4 */
layout(location = 0) out vec4 outColor;     // colortex3
layout(location = 1) out vec4 outData;      // colortex4
#endif

void main() {
    vec3 geoNormal = normalize(worldNormal);
    if (!gl_FrontFacing) geoNormal = -geoNormal;
    float dither = gradientNoise(gl_FragCoord.xy);

#ifdef PROG_WATER
    if (blockId == ID_WATER) {
        vec3 worldPos = playerPos + cameraPosition;
        vec3 n = geoNormal;
        float dist = length(playerPos);
        if (abs(geoNormal.y) > 0.5) {
            // animated wave normal; small octaves fade out with distance
            int octaves = dist > 72.0 ? max(WAVE_OCTAVES / 2, 4) : WAVE_OCTAVES;
            float strength = WAVE_STRENGTH * 0.9 / (1.0 + dist * 0.012);
            vec3 wn = waterNormal(worldPos.xz, octaves, strength);
            n = geoNormal.y > 0.0 ? wn : vec3(wn.x, -wn.y, wn.z);
        } else {
            // falling water / sides: a fast scrolling ripple
            float r = valueNoise(vec2(dot(worldPos.xz, vec2(1.0)) * 2.0, worldPos.y * 1.5 + frameTimeCounter * 6.0));
            n = normalize(geoNormal + vec3(0.0, 1.0, 0.0) * (r - 0.5) * 0.25);
        }
        outData  = vec4(encodeNormal(n), packMatSky(TMAT_WATER, lmcoord.y), 1.0);
        outColor = vec4(0.0);
        outExtra = vec4(lmcoord.x, packColor565(glcolor.rgb), 0.0, 1.0);
        return;
    }
#endif

    vec4 albedo = texture(gtexture, texcoord) * glcolor;
    if (albedo.a < 0.01) discard;
    vec3 srgb = albedo.rgb;
    albedo.rgb = toLinear(albedo.rgb);

    float emission = 0.0;
    float tmat = TMAT_OTHER;
    float smoothness = 0.0;
#ifdef PROG_WATER
    emission = blockEmission(blockId, srgb);
    if (blockId == ID_GLASS) { tmat = TMAT_GLASS; smoothness = 0.95; }
    else if (blockId == ID_ICE) { tmat = TMAT_GLASS; smoothness = 0.92; }
    else if (blockId == ID_SLIME_HONEY) { smoothness = 0.6; }
#endif

    vec3 color = shadeSurface(albedo.rgb, geoNormal, lmcoord, playerPos, 0.0,
                              smoothness, 0.0, directCol, ambientCol, dither);
    color += albedo.rgb * emission;

    outColor = vec4(color, albedo.a);
#ifdef PROG_WATER
    outData  = vec4(encodeNormal(geoNormal), packMatSky(tmat, lmcoord.y), 1.0);
    outExtra = vec4(lmcoord.x, 0.0, 0.0, 1.0);
#else
    // held translucent items: block water/glass processing under the hand
    outData  = vec4(0.5, 0.5, packMatSky(TMAT_NONE, 0.0), 1.0);
#endif
}

#endif
