/*
    YAKAMOZ SHADERS - composite2.glsl  (atmospheric fog & god rays)

    * exponential height fog integrated analytically along the view ray,
      coloured by the sky in the same direction (aerial perspective)
    * a soft render-distance fade into the sky
    * morning mist that settles in valleys around sunrise
    * underwater / lava / powder-snow fog
    * the volumetric light buffer, depth-aware blurred, added on top
*/

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/common.glsl"
#include "/lib/materials.glsl"
#include "/lib/atmosphere.glsl"
#include "/lib/shadows.glsl"
#include "/lib/waves.glsl"
#include "/lib/lighting.glsl"
#include "/lib/water.glsl"

// ================================================================
#ifdef VSH

out vec2 texcoord;
flat out vec3 directCol;
flat out vec3 ambientCol;

void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
    getLightColors(directCol, ambientCol);
}

#endif
// ================================================================
#ifdef FSH

in vec2 texcoord;
flat in vec3 directCol;
flat in vec3 ambientCol;

uniform sampler2D colortex0;
uniform sampler2D colortex6;
uniform sampler2D depthtex0;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

float heightFog(float y0, float dirY, float dist, float density, float falloff) {
    float a = density * exp(-clamp(y0 - 63.0, -30.0, 400.0) * falloff);
    float b = dirY * falloff;
    float integral = abs(b) > 1e-4 ? a * (1.0 - exp(-b * dist)) / b : a * dist;
    return 1.0 - exp(-max(integral, 0.0));
}

vec3 blurredVolumetrics(vec2 uv, float centerZ) {
#if defined VOLUMETRIC_LIGHT && defined WORLD_OVERWORLD
    vec2 px = 1.5 / vec2(viewWidth, viewHeight);
    vec3 sum = vec3(0.0);
    float wsum = 0.0;
    for (int x = -1; x <= 1; x++) {
        for (int y = -1; y <= 1; y++) {
            vec2 suv = uv + vec2(float(x), float(y)) * px;
            float z = -screenToView(suv, texture(depthtex0, suv).r).z;
            float w = exp(-abs(z - centerZ) / (centerZ * 0.08 + 0.3));
            sum += texture(colortex6, suv).rgb * w;
            wsum += w;
        }
    }
    return sum / max(wsum, 1e-4);
#else
    return vec3(0.0);
#endif
}

void main() {
    vec3 color = texture(colortex0, texcoord).rgb;
    float depth = texture(depthtex0, texcoord).r;
    bool isSky = depth >= 1.0;

    vec3 viewPos = screenToView(texcoord, depth);
    vec3 playerPos = viewToPlayer(viewPos);
    float dist = length(viewPos);
    vec3 dirW = normalize(playerPos);
    float eyeSky = float(eyeBrightnessSmooth.y) / 240.0;

    if (isEyeInWater == 0) {
        if (!isSky) {
#if defined WORLD_OVERWORLD
            vec3 fogCol = skyAtmosphere(dirW);
            fogCol = mix(vec3(0.006, 0.008, 0.011), fogCol, smoothstep(0.0, 0.7, eyeSky));
            float density = (0.0012 + rainStrength * 0.006) * FOG_DENSITY;
            float fog = heightFog(cameraPosition.y, dirW.y, dist, density, 0.018);
#ifdef MORNING_MIST
            float sunY = sunDirection().y;
            float mist = 0.006 * exp(-sq((sunY - 0.08) * 7.0)) * (1.0 - rainStrength) * FOG_DENSITY;
            fog = 1.0 - (1.0 - fog) * (1.0 - heightFog(cameraPosition.y, dirW.y, dist, mist, 0.09));
#endif
            float border = smoothstep(far * 0.72, far * 0.98, length(playerPos.xz));
            color = mix(color, fogCol, max(fog, border));
#elif defined WORLD_NETHER
            vec3 fogCol = toLinear(fogColor) * 0.6;
            float fog = 1.0 - exp(-dist * 0.011 * FOG_DENSITY);
            fog = max(fog, smoothstep(far * 0.6, far * 0.95, dist));
            color = mix(color, fogCol, fog);
#else
            vec3 fogCol = vec3(0.020, 0.012, 0.030);
            float fog = 1.0 - exp(-dist * 0.004 * FOG_DENSITY);
            fog = max(fog, smoothstep(far * 0.7, far * 0.98, dist));
            color = mix(color, fogCol, fog);
#endif
        }
    } else if (isEyeInWater == 1) {
        vec3 light = (directCol * 0.5 + ambientCol) * max(eyeSky * eyeSky, 0.03) + blockLight(float(eyeBrightnessSmooth.x) / 240.0) * 0.3;
        color = waterVolume(color, isSky ? 256.0 : dist, DEFAULT_WATER_TINT, light);
    } else if (isEyeInWater == 2) {
        color = mix(color, vec3(1.6, 0.35, 0.04), 1.0 - exp(-dist * 0.9));
    } else {
        color = mix(color, vec3(0.55, 0.65, 0.8) * (ambientCol + 0.05), 1.0 - exp(-dist * 0.8));
    }

    color += blurredVolumetrics(texcoord, -viewPos.z);

    // blindness / darkness effect
    float dark = max(blindness, darknessFactor);
    if (dark > 0.0) color *= isSky ? 1.0 - dark : mix(1.0, exp(-dist * 0.35), dark);

    if (any(isnan(color)) || any(isinf(color))) color = vec3(0.0);
    outColor = vec4(min(color, vec3(30000.0)), 1.0);
}

#endif
