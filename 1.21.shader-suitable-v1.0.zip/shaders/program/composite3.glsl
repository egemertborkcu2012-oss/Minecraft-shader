/*
    YAKAMOZ SHADERS - composite3.glsl  (bloom: downsample + horizontal blur)
    Uses hardware mipmaps of the HDR scene as the downsampled source.
*/

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/common.glsl"
#include "/lib/bloom.glsl"

// ================================================================
#ifdef VSH

out vec2 texcoord;

void main() {
    gl_Position = ftransform();
    texcoord = gl_MultiTexCoord0.xy;
}

#endif
// ================================================================
#ifdef FSH

in vec2 texcoord;

uniform sampler2D colortex0;
const bool colortex0MipmapEnabled = true;

/* RENDERTARGETS: 7 */
layout(location = 0) out vec4 outBloom;

void main() {
    vec3 result = vec3(0.0);
#ifdef BLOOM
    for (int i = 0; i < BLOOM_TILES; i++) {
        float s = bloomTileScale(i);
        vec2 local = (texcoord - bloomTileOffset(i)) / s;
        if (all(greaterThanEqual(local, vec2(0.0))) && all(lessThanEqual(local, vec2(1.0)))) {
            float lod = float(i + 2);
            float texelX = 1.0 / (viewWidth * s);
            vec3 sum = vec3(0.0);
            float wsum = 0.0;
            for (int k = -4; k <= 4; k++) {
                float w = bloomWeight(k);
                vec2 suv = clamp(vec2(local.x + float(k) * texelX, local.y), vec2(0.0), vec2(1.0));
                sum += textureLod(colortex0, suv, lod).rgb * w;
                wsum += w;
            }
            result = sum / wsum;
            break;
        }
    }
#endif
    outBloom = vec4(result, 1.0);
}

#endif
