/*
    YAKAMOZ SHADERS - shadow.glsl
    Shadow map pass. Geometry is distorted (more resolution near the
    player). Translucent blocks write their transmitted colour into
    shadowcolor0; water writes an animated caustic pattern computed from
    the very same wave field that shapes the surface.
*/

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/common.glsl"
#include "/lib/materials.glsl"
#include "/lib/shadows.glsl"
#include "/lib/waves.glsl"

// ================================================================
#ifdef VSH

#include "/lib/waving.glsl"

in vec2 mc_Entity;
in vec2 mc_midTexCoord;

out vec2 texcoord;
out vec4 glcolor;
out vec3 worldPos;
flat out int blockId;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor  = gl_Color;
    blockId  = int(mc_Entity.x + 0.5);

    vec3 playerPos = (shadowModelViewInverse * (gl_ModelViewMatrix * gl_Vertex)).xyz;
    vec2 lm = getLightmapCoord();
    bool topVertex = gl_MultiTexCoord0.t < mc_midTexCoord.t;
    playerPos += waveVertex(playerPos + cameraPosition, blockId, topVertex, lm.y);
    worldPos = playerPos + cameraPosition;

    vec4 clip = gl_ProjectionMatrix * (shadowModelView * vec4(playerPos, 1.0));
    clip.xyz = distortShadowClip(clip.xyz);
    gl_Position = clip;
}

#endif
// ================================================================
#ifdef FSH

in vec2 texcoord;
in vec4 glcolor;
in vec3 worldPos;
flat in int blockId;

uniform sampler2D gtexture;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outShadowColor;

void main() {
    if (blockId == ID_WATER) {
        vec3 tint = mix(vec3(0.62, 0.86, 0.92), sqrt(sat(glcolor.rgb)), WATER_BIOME_TINT * 0.6);
        float caustic = 1.0;
#ifdef WATER_CAUSTICS
        caustic = waterCaustics(worldPos.xz);
#endif
        outShadowColor = vec4(tint * caustic / SHADOWCOLOR_SCALE, 1.0);
        return;
    }

    vec4 albedo = texture(gtexture, texcoord) * glcolor;
    if (albedo.a < 0.1) discard;

    // light passing through stained glass / ice / slime takes on its colour
    vec3 transmitted = mix(vec3(1.0), toLinear(albedo.rgb), sat(albedo.a * 1.5));
    outShadowColor = vec4(transmitted / SHADOWCOLOR_SCALE, 1.0);
}

#endif
