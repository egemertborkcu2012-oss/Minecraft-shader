/*
    YAKAMOZ SHADERS - gbuffers_simple.glsl
    Small programs that only touch colortex0:
      PROG_BASIC        gbuffers_basic        (block outline, leads, debug lines)
      PROG_DAMAGED      gbuffers_damagedblock (breaking overlay, multiplicative)
      PROG_GLINT        gbuffers_armor_glint  (enchantment glint, additive)
      PROG_EMISSIVE     gbuffers_spidereyes / gbuffers_beaconbeam
      PROG_LIGHTNING    gbuffers_lightning
      PROG_SKYBASIC     gbuffers_skybasic     (discarded: sky is procedural)
      PROG_SKYTEXTURED  gbuffers_skytextured  (vanilla moon with phases)
      PROG_CLOUDS       gbuffers_clouds       (discarded: clouds are procedural)
*/

#include "/lib/settings.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/common.glsl"

// ================================================================
#ifdef VSH

out vec2 texcoord;
out vec4 glcolor;
out vec3 viewPos;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor  = gl_Color;
    viewPos  = (gl_ModelViewMatrix * gl_Vertex).xyz;
    gl_Position = ftransform();
}

#endif
// ================================================================
#ifdef FSH

in vec2 texcoord;
in vec4 glcolor;
in vec3 viewPos;

uniform sampler2D gtexture;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

void main() {
#if defined PROG_SKYBASIC || defined PROG_CLOUDS
    outColor = vec4(0.0);
    discard;
#elif defined PROG_BASIC
    outColor = vec4(toLinear(glcolor.rgb), glcolor.a);
#elif defined PROG_DAMAGED
    // multiplicative blend: keep the texture in display space (0.5 = no change)
    vec4 tex = texture(gtexture, texcoord) * glcolor;
    outColor = tex;
#elif defined PROG_GLINT
    vec4 tex = texture(gtexture, texcoord) * glcolor;
    outColor = vec4(toLinear(tex.rgb) * 0.6, tex.a);
#elif defined PROG_EMISSIVE
    vec4 tex = texture(gtexture, texcoord) * glcolor;
    if (tex.a < 0.02) discard;
    outColor = vec4(toLinear(tex.rgb) * (3.5 * EMISSIVE_BRIGHTNESS), tex.a);
#elif defined PROG_LIGHTNING
    outColor = vec4(toLinear(glcolor.rgb) * vec3(6.0, 7.0, 9.0), glcolor.a);
#elif defined PROG_SKYTEXTURED
    vec4 tex = texture(gtexture, texcoord) * glcolor;
#if defined WORLD_OVERWORLD
    // the sun is drawn procedurally; keep the vanilla moon (it carries the phases)
    if (dot(normalize(viewPos), normalize(sunPosition)) > 0.0) discard;
    outColor = vec4(toLinear(tex.rgb) * vec3(2.3, 2.6, 3.1), tex.a);
#elif defined WORLD_END
    outColor = vec4(0.0);
    discard;
#else
    outColor = vec4(toLinear(tex.rgb), tex.a);
#endif
#else
    vec4 tex = texture(gtexture, texcoord) * glcolor;
    outColor = vec4(toLinear(tex.rgb), tex.a);
#endif
}

#endif
